(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)
(** Symbolic execution *)
open Misc
open Exp
open Assertions
open Commands
open Genarith
open Actions
open Parsetree
open Tycheck

(* -------------------------------------------------------------------------- *)
(** {2 Shorthands} *)
(* -------------------------------------------------------------------------- *)

let (@%) ((pl,sl),scpl) pl' = ((Pure.conj pl' pl,sl),scpl)
let (@&) = Pure.conj_one
let (@@***) x y = eprop_star_assume x y
let (@@**) x y = eprop_star x y
let (@@&&) x y = cprop_pure x @@** y
let (@@&)  x y = Pure.one x @@&& y

let print loc = Location.print (!Misc.formatter) loc; pp 

let pp_generated_function fname n =
  if Genarith.enabled () then pp_function !Misc.formatter (fname,n)

let cform_to_sub ((p,_),_) = Pure.to_sub p

(* -------------------------------------------------------------------------- *)
(** {2 Arguments} *)
(* -------------------------------------------------------------------------- *)

(**
   If [verbose >= 1] 
   If [verbose >= 2], print loop invariants & actions inferred.
   If [verbose >= 3], print verification condition & action inference.
   If [verbose >= 4], print intermediate states.
   If [verbose >= 5], print stabilizations.
   If [verbose >= 6], print inferred frames.
*)
let verbose = ref 1

let log_level = ref 0

let debug_lf = ref 0

let args = 
  [("-vSE", Arg.Set_int verbose, "<n> Display internal information (symbolic execution)");
   ("-debug_lf", Arg.Set_int debug_lf, "<n> Filter displayed assertions for debugging LF prover");
   ("-vvSE", Arg.Set_int log_level, "<n> Display debug information (symbolic execution)")]

let pp_line () =
  if !verbose >= 1 then
    pp "----------------------------------------------------------------------------@."

let pp_comment s =
  if !verbose >= 1 then begin
    pp "@.";
    if Genarith.enabled () then pp "// ";
    pp "%s@." s
  end

let pp_internal_error () =
  pp "@.Internal error: please report.@."

let dumb_formatter =
  let out _ _ _ = () in
  let flush _ = () in
  Format.make_formatter out flush

let debug s =
  if !log_level >= 1 then
    pp s
  else
    Format.fprintf dumb_formatter s

(* -------------------------------------------------------------------------- *)
(** {2 Error handling} *)
(* -------------------------------------------------------------------------- *)

(** Internal exception *)
exception Symbolic_execution_error

let error_noframe loc s cp1 cp2 =
  if !verbose >= 1 then 
    print loc "ERROR cannot find frame: %s@.@[<hv>@[<hov 2>%a@]@ |-@ @[<hov 2>%a@]@]@." s 
      pp_cprop cp1 pp_cprop cp2;
  raise Symbolic_execution_error

let error_noframe_ext loc s ep1 cp2 =
  error_noframe loc s (List.map cform_of_eform ep1) cp2

let test_leakmem ?(warn=true) loc cp =
  if is_cprop_empty cp then ()
  else if !allow_leaks then begin
    if !verbose >= 1 && warn then
      print loc "WARNING memory leak:@.%a@." pp_cprop cp
    else ()
  end else begin
    if !verbose >= 1 then print loc "ERROR memory leak:@.%a@." pp_cprop cp;
    raise Symbolic_execution_error
  end

let error_heap loc e ep =
  if !verbose >= 1 then
    print loc "ERROR: %a is possibly unallocated in@.%a@." 
      pp_exp e pp_eprop ep;
  raise Symbolic_execution_error

let error_heap2 loc s ep =
  if !verbose >= 1 then 
    print loc "ERROR: %s with precondition@.%a@." s pp_eprop ep;
  raise Symbolic_execution_error


(* -------------------------------------------------------------------------- *)
(** {2 Global variables} *)
(* -------------------------------------------------------------------------- *)

type global_env = 
  { g_prover : prover
  ; g_abstraction : abstraction
  ; mutable g_globals : IdSet.t
  ; g_pro_ht : (string, protocol_item) Hashtbl.t
  ; g_esc_ht : (string, escrow_item) Hashtbl.t
  ; g_fun_ht : (string, fun_info) Hashtbl.t
  ; g_res_ht : (component, (act list * act list)) Hashtbl.t
  ; g_renv   : (component, cprop) Hashtbl.t
  ; g_guar   : guar_env 
  ; mutable g_actinf : bool
  ; mutable g_params : IdSet.t
  ; g_no_interf_hack : bool   (** Assume no interference occurs *)
  ; g_por_hack : bool         (** Avoid stabilization when POR possible *)
  ; mutable g_linear_pure_code: can_cmd
  ; g_linear_pre : cprop option    (** Fail quickly for linearizability checking *)
  }

let ident_ABS       = Id.create "ABS"
let ident_ABS_value = Id.create "ABS_value"

let udom_false = udom_of_uform_list []

let normalize_uforms_aggr =
  List.reduce 
    (fun (p,sl) res -> 
       List.fold_append (fun p -> normalize_uform (p,sl))
         (Pure.normalize_aggr p) res)

let normalize_cforms_aggr =
  List.reduce 
    (fun ((p,sl),scpl) res -> 
       List.fold_append (fun p -> normalize_cform ((p,sl),scpl))
         (Pure.normalize_aggr p) res)


(** Return [true] if the correlation between the abstract state and
    the concrete state been broken. *)
let linear_bad_invariant (p,sl) =
  let (sl1,sl2) = List.partition 
    (function Csp_node(_,_,i,_,_) -> i == E.id ident_ABS | _ -> false)
    sl in
  let sl1_fv = List.fold
    (fun sp r -> match sp with Csp_node(_,_,_,fld,_) -> 
       Fld.fold (fun t e r -> if t == Misc.list_data_tag then E.exfv e r else r) fld r | _ -> r)
    sl1 IdSet.empty in
  let sl2_fv = spat_fold E.exfv sl2 IdSet.empty in
  not (IdSet.subset sl1_fv sl2_fv)

let linear_abs_pre = 
  (Pure.ptrue, [Csp_node(tag_default, node_component, E.id ident_ABS,
                        Fld.one Misc.list_data_tag (E.id ident_ABS_value),tag2_default)])

let str_is_fair x     = Str.string_match (Str.regexp_string "fair") x 0
let str_is_cutpoint x = (x = "cutpoint")

let cutpoint_counter  = ref 0

let next_cutpoint () =
  incr cutpoint_counter;
  "CUTPOINT_" ^ string_of_int (!cutpoint_counter)

(** Given an eprop, expose [e|->_] in each disjunct. *)
let ext_expose_ptsto prover e ep =
  ext_transform
    (fun cf -> prover.expose_ptsto (cprop_cform cf) e)
    ep

(** Put [ep] into normal form *)
let ext_normalize prover ep =
  ext_transform
    (fun cf -> prover.nf_cprop [] (cprop_cform cf))
    ep

(** Compute [er] such that [ep |- cq * er] *)
let ext_subtract prover ep cq =
  ext_transform
    (fun cf -> prover.find_frame_cprop [] (cprop_cform cf) cq)
    ep

(** Compute [cr] such that [ep |- eq * cr] *)
let ext_ext_subtract prover ep eq =
  let rec go l cf = match l with
    | [] -> raise (No_frame_found "ext_ext_subtract")
    | x::xl ->
	let cp1 = cprop_cform (cform_of_eform cf) in
	let cp2 = cprop_cform (cform_of_eform x)  in
	try
	  let res = prover.find_frame_cprop [] cp1 cp2 in
	  put_edge_skip(*TODO*) cf x;
	  res
	with No_frame_found _ -> go xl cf in
  aggr_remove_cform_duplicates 
    (List.reduce_append (go eq) ep)

(** Calculate postcondition after executing a generic command *)
let execute_gen_cmd subtract (modif,cp,cq,s',loc) epre =
  let epre = ext_append_assign (IdSet.fold (fun x r -> (x,None)::r) modif []) epre in
  let sub_modif = mk_gensym_garb_subst_idset modif in
  let fr =
    try subtract epre cp
    with No_frame_found _ -> error_noframe_ext loc s' epre cp in
  (if !verbose >= 6 then
     print loc "FRAME inferred:@.@[<hov 2>%a@]@." pp_eprop fr);
  cq @@*** map_eprop sub_modif fr

(** find the pure part of a proposition *)
let pure_part ep = 
  (*let intersection pl pl' = Pure.filter (fun ca -> mem_atom ca pl) pl' in *)
  let rec go = function
    | [] -> Pure.ptrue
    | [n] -> fst (fst (cform_of_eform n))
    | n::cfl -> Pure.ptrue (*intersection pl (go cfl)*) in
  go ep


(** Simple symbolic execution for pure linearization checkers & eff. specs *)
let rec linear_symbexe prover c vars ufl = match c with
  | [] ->
      let sub = mk_gensym_garb_subst_idset vars in
      List.reduce_append (map_uform sub) ufl
  | c0 :: c -> begin match c0.can_st_desc with 
      | Cst_nondet (c1,c2) ->
	  linear_symbexe prover (c1 @ c) vars ufl
	  @ linear_symbexe prover (c2 @ c) vars ufl
      | Cst_kill ids ->
	  let sub = mk_gensym_garb_subst_idset ids in
	  let ufl = List.reduce_append (map_uform sub) ufl in
	  linear_symbexe prover c (IdSet.diff vars ids) ufl
      | Cst_assign (x,e) ->
	  let sub = mk_gensym_garb_subst x in
	  let eq = E.eq (E.id x) (sub e) in
	  let ufl = List.reduce
	    (fun uf res -> List.fold_append
	       (fun (p,sl) -> normalize_uform (eq @& p,sl))
	       (map_uform sub uf) res) ufl in
	  linear_symbexe prover c (IdSet.add x vars) ufl
      | Cst_fldlookup (_rgnl,x,e,t,mo) ->
	  (* FIXME deal with mo *)
	  let ufl = List.reduce
	    (fun (p,sl) res ->
	       let sub = mk_gensym_garb_subst x in
	       let e = Pure.to_sub p e in
	       try
		 let (cel,_) = prover.find_ptsto node_component e sl in
		 let eq = E.eq (E.id x) (sub (Fld.get t cel)) in
		 List.fold (fun uf res -> List.fold_append
			     (fun (p,sl) -> normalize_uform (eq @& p,sl))
			     (map_uform sub uf) res)
		   ufl res
	       with Not_found -> List.fold_append (map_uform sub) ufl res)
	    ufl in
	  linear_symbexe prover c (IdSet.add x vars) ufl
      | Cst_assume cp ->
	  let ufl = List.reduce
	    (fun ((p_new,_),_) res -> List.fold
	       (fun (p,sl) res -> 
		  List.fold_append (fun p -> normalize_uform (p,sl))
		    (Pure.normalize_aggr (Pure.conj p_new p))
		    res)
	       ufl res)
	    cp in
	  linear_symbexe prover c vars ufl
      | Cst_assume_exp e ->
          let p_new = Pure.one e in
	  let ufl = List.reduce
	       (fun (p,sl) res -> 
		  List.fold_append (fun p -> normalize_uform (p,sl))
		    (Pure.normalize_aggr (Pure.conj p_new p))
		    res) ufl in
	  linear_symbexe prover c vars ufl
      | Cst_fldassign (_rgnl,[(e1,t,e2)],_,mo) ->
	  (* FIXME deal with mo *)
	  let ufl = List.reduce
	    (fun (p,sl) res ->
	       let e1 = Pure.to_sub p e1 in
	       try
		 let (cel,rest) = prover.find_ptsto node_component e1 sl in
		 let cel' = Fld.set t (Pure.to_sub p e2) cel in
		 (p, Csp_node (tag_default, node_component, e1, cel',tag2_default) :: rest) :: res
	       with Not_found -> pp_internal_error (); assert false (*TODO*))
	    ufl in
	  linear_symbexe prover c vars ufl
      | Cst_assert_exp _ 
      | Cst_fcall2 _ -> (*TODO---------------------------HACK_______________ *)
	  linear_symbexe prover c vars ufl
      | Cst_cas _
      | Cst_fldassign _ | Cst_new _ | Cst_dispose _ | Cst_pfcall _ 
      | Cst_action_begin _ | Cst_action_end _ | Cst_interfere _ 
      | Cst_stabilize _ | Cst_loop _ | Cst_goto _ | Cst_comment _ ->
          pp_internal_error ();
          pp "Linear cmd: %a@." pp_cmd (c0::c);
          assert false
    end

(** Calculate post-condition outside block *)
let exit_from_block prover (rid,modif_body,cq0,loc) cq =
  let rec remove_box rid = 
    ext_transform 
      (fun (uf,scpl) -> cprop_cform (uf, PList.remove_assq rid scpl)) in
  let get_shared n cq_shared =
    let cf = cform_of_eform n in
    let fr = try PList.assq rid (snd cf) 
             with Not_found -> pp_internal_error (); assert false in
    cprop_or cq_shared (and_cprop_pure (cprop_star fr cq0) (fst (fst cf))) in
  let cq_local = (* local part of post-condition *) 
    try ext_subtract prover cq cq0
    with No_frame_found _ -> error_noframe_ext loc "action exit" cq cq0 in
  let cq_shared = List.reduce get_shared cq_local in
  let cq_shared = and_cprop_pure cq_shared (pure_part cq_local) in
  let sub = mk_gensym_garb_subst_idset modif_body in
  let cq_local = remove_box rid cq_local in
  let cq_local = map_eprop sub cq_local in
  let cq = cprop_box rid cq_shared @@*** cq_local in
  let cq = 
    let cq_local = List.map cform_of_eform cq_local in
    let sub = mk_gensym_garb_subst_idset (prop_exfv cq_local IdSet.empty) in
    map_eprop sub cq in
  ext_normalize prover cq

(** A bogus assertion, used when abstraction raises [Junk]. *)
let junk_node =
  cprop_spred
    [Csp_node(tag_default,component_of_string "Junk",E.id Id.junk,Fld.emp,tag2_default)]

(* FIXME: this is a hack to avoid branches instead of the 
   straightforward [linear_symbexe prover (env.g_linear_pure_code)].
 *)
let exec_pure_lin_checker env =
  match env.g_linear_pure_code with [] -> identity | _::_ ->
  List.reduce
    (fun uf acc ->
       if Pure.to_sub (fst uf) (E.id ident_lin_res) == E.undef then
         let res = 
           linear_symbexe env.g_prover env.g_linear_pure_code IdSet.empty [uf] 
           |> normalize_uforms_aggr
         in
         match res with [uf] -> uf :: acc
         | [] -> acc
         | (p,_)::ufl' -> 
           let pcomm = List.fold (fun (p,_) res -> Pure.common p res) ufl' p in
	   let (res_cr, res_o) = 
             List.partition (fun (p,_) -> Pure.has_can_return (Pure.simplify pcomm p)) res in
           match res_cr, res_o with
	     | _::_, _::_ -> res@acc
             | _ -> 
	   (* pp "ex_p: %a@.all: %a@."
             pp_cprop (cprop_pure pcomm) 
             pp_cprop (List.map (fun uf -> (uf,PNil)) res) ; *)
           (Pure.conj pcomm (fst uf), snd uf) :: acc
       else uf :: acc)


(** computes the fixpoint of a transformation from propositions to
    propositions, such as the symbolic execution function *)
let compute_transf_fixpoint env (transf: eprop -> eprop) ep loc =
  let rec fix ep_total ep ep_new =
    if ep_new = [] then ep
    else 
      let ep_new = transf ep in
      let (ep_total,ep,ep_new) = env.g_abstraction.prop_join ep_total ep ep_new in
      let _ = if !verbose >= 3 then pp "@.LOOP ADDING:@.%a@." pp_eprop ep_new in
      fix ep_total ep ep_new
  in
  try
    (* 1. Do an initial abstraction *)
      (* This step is optional: abstracts the initial value.
         Intuitively it should speed up the analysis slightly.
         In practice, it does not affect performance in the 3 list algorithms. *)
    let ep = env.g_abstraction.prop_abs ep in
    let _ = if !verbose >= 3 then pp "@.LOOP STARTING (%s):@.%a@." (Location.lineno_to_string loc) pp_eprop ep in
    (* 2. Calculate fix-point *)
    let pfix = fix ep ep ep in
    let _ = 
      if !verbose >= 2 && not (Genarith.enabled ()) then
        if env.g_no_interf_hack then begin
          if !verbose >= 3 then 
            pp "@.LOOP NO-INTERFERENCE INV (%s):@.%a@."
               (Location.lineno_to_string loc)
               pp_eprop pfix 
        end else
	  pp "@.FOUND LOOP INVARIANT (%s):@.%a@." 
             (Location.lineno_to_string loc)
             pp_eprop pfix in
    pfix
  with
    Junk -> eprop_of_cprop junk_node



(** Hack to work around awkward semantics of [e|->fld]. *)
let all_fields = ref StringSet.empty 

let populate_fields fld =
  let rec go s fld =
    let s = component_of_string s in
    if Fld.hasfld s fld then fld 
    else Fld.set s (E.id (Id.gensym_str_ex (string_of_component s))) fld in
  StringSet.fold go !all_fields fld


let get_reachable froml sl =
  let add x y = if List.exists (fun y -> equal_exp x y) y then y else x::y in
  let add_reach_vars res sp = match sp with
    | Csp_node (_,_,_,fld,_) -> Fld.fold_val add fld res
    | Csp_listsegi(_,_,e,f,g,h,_,_) -> add e (add f (add g (add h res)))
    | Csp_arr (_,e,f,g,_,_,_) -> add e (add f (add g res))
    | Csp_escrow _ | Csp_atomic_fld _ | Csp_token _ 
    | Csp_indpred _ -> res  in
  let is_pred_reachable x sp = match sp with
    | Csp_arr (_,e,_,_,_,_,_) (*TODO*)
    | Csp_node (_,_,e,_,_) -> equal_exp x e
    | Csp_listsegi(_,SINGLE _,e,_,_,_,_,_) -> equal_exp x e
    | Csp_listsegi(_,(XOR _ | DOUBLE _),e1,_,e2,_,_,_) -> equal_exp x e1 || equal_exp x e2
    | Csp_escrow _ | Csp_atomic_fld _ | Csp_token _ 
    | Csp_indpred _ -> false in
  let rec go_reach seen todo sl1 sl2 = match todo with
    | [] -> (sl1, sl2)
    | x::todo -> 
	let (sl1new,sl2) = List.partition (is_pred_reachable x) sl2 in
	let seen = x::seen in
	let todo = List.fold_left add_reach_vars todo sl1new in
	let todo = List.filter (fun x -> not (List.exists (fun y -> equal_exp x y) seen)) todo in
	go_reach seen todo (sl1new @ sl1) sl2 in
  go_reach [] froml [] sl

(** Helper function *)
let reduce_list f cfl =
  let g reso cf =
    reso >>= fun res ->
    f cf >>= fun cfl -> Some (List.rev_append cfl res) in
  List.fold_left g (Some []) cfl


(* -------------------------------------------------------------------------- *)
(** {2 Symbolic execution of field lookup and update} *)
(* -------------------------------------------------------------------------- *)

(** In the context [rctx], calculate the postcondition 
    of executing [x = e->t] given the precondition [cpre]. *)
let execute_fld_lookup prover rctx x e t cpre =
  (* Old value of x is now garbage *)
  let sub = mk_gensym_garb_subst x in
  (* Read from cf *)
  let rec go_simp e rctx ((pl2,sl2),scpl2) =
    let e = (Pure.to_sub pl2) e in
    try
      let (cel,sl2b) = prover.find_ptsto node_component e sl2 in
      let (f,cel') = Fld.get_extend t cel in
      let f' = sub f in
      let cp = map_cform sub ((pl2,Csp_node(tag_default,node_component,e,cel',tag2_default)::sl2b),scpl2) in
      Some (and_cprop_pure cp (Pure.one (E.eq (E.id x) f')))
    with Not_found -> 
      go_ctx e rctx ((pl2,sl2),scpl2)
  and go e rctx cf = 
    let cp = prover.expose_ptsto (cprop_cform cf) e in
    reduce_list (go_simp e rctx) cp
  and go_ctx e rctx ((pl2,sl2),scpl2) =
    match rctx with
    | [] -> None
    | rid::rctx ->
	try match reduce_list (go e []) (and_cprop_pure (PList.assq rid scpl2) pl2) with
	  | None -> go_ctx e rctx ((pl2,sl2),scpl2)
	  | Some cfl -> 
	      let cp2 =  map_cform sub ((pl2,sl2), PList.remove_assq rid scpl2) in
	      Some (List.map (fun (uf2, scpl2) -> (uf2, PCons (rid, cfl, scpl2))) cp2)
	with Not_found -> go_ctx e rctx ((pl2,sl2),scpl2) in
  let go_ext_simp e rctx n =
    ext_opt_transform1 (go_simp e rctx) n in
  let go_ext e rctx n =
    ext_expose_ptsto prover e [n]
    |> reduce_list (go_ext_simp e rctx) in
  reduce_list (go_ext e rctx) cpre


(** In the context [rctx], calculate the postcondition 
    of executing [e1->t1 = f1, ... en->tn = fn] given the precondition [cpre]. *)
let execute_fld_assign env actlr rctx assignl cpre =
  (* Deal with shared writes *)
  let go_shared (rid : component) ((pl_local,sl_local),scpl) ((pl_shared,sl_shared),scpl') =
    (* TODO :: Normalize cf_local * pl_shared ! *)
    try
      let (old_vals,new_vals,old_nodes,new_nodes,sl_rem_shared) = 
	let sub = Pure.to_sub pl_shared in
	List.fold_left
	  (fun (e2_olds,e2s,old_nodes,new_nodes,sl_rem_shared) (e1,t,e2) ->
	     let e1 = sub e1 in
	     let e2 = sub e2 in
	     let (cel,sl_rem_shared) = 
	       env.g_prover.find_ptsto node_component e1 sl_rem_shared in
	     let cel = populate_fields cel in
	     let (e2_olds, e2) = (* HACK -- abstraction for unlocking actions *)
	       match Fld.try_get t cel with
	       | Some e2_old ->
		   if e2 == E.zero && e2_old == E.tid then
		       (e2_old::e2_olds, E.id (Id.gensym_str_ex "unlock"))
		   else 
		     (e2_old::e2_olds, e2)
	       | None -> (e2_olds, e2) in
	     let e2s = e2::e2s in
	     let (old_nodes, new_nodes,sl_rem_shared) =
	       match Fld.try_get t cel with
	       | Some e2_old when equal_exp e2_old e2 ->
		 (old_nodes,new_nodes,Csp_node(tag_default,node_component,e1,cel,tag2_default)::sl_rem_shared)
	       | _ ->
	         (Csp_node(tag_default,node_component,e1,cel,tag2_default)::old_nodes,
		  Csp_node(tag_default,node_component,e1,Fld.set t e2 cel,tag2_default)::new_nodes,
                  sl_rem_shared) in
	     (e2_olds,e2s,old_nodes,new_nodes,sl_rem_shared))
	  ([],[],[],[],sl_shared) assignl in
      (* Ownership transfer: private -> shared *)
      let (sl_transf_to_shared,sl_local) = get_reachable new_vals sl_local in
      (* Ownership transfer: shared -> private *)
      let (sl_transf_to_local,sl_rem_shared) = 
	if !allow_leaks then ([],sl_rem_shared)
	else 
	  let sl3 = spat_star new_nodes (spat_star sl_transf_to_shared sl_rem_shared) in 
	  let (_,transf) = get_reachable (List.map E.id (IdSet.elements env.g_globals)) sl3 in
	  let (transf,_) = get_reachable old_vals transf in
	  List.partition (fun sp -> List.exists (fun x -> compare_can_spred sp x = 0) transf) sl_rem_shared in
      (* Results *)
      let _ = 
	if !verbose >= 4 && sl_transf_to_local <> [] then
	  pp "ACTION: BECOME LOCAL =@ %a@.SL2 =@ %a@."
	    pp_uform (Pure.ptrue, sl_transf_to_local)
	    pp_uform (Pure.ptrue, sl_rem_shared) in
      let cp_ctx = env.g_prover.nf_cprop [] (cprop_spred sl_rem_shared) in
      let cp_pre = 
	let sl_pre = spat_star old_nodes sl_transf_to_local in
	env.g_prover.nf_cprop [] (cprop_uform (pl_shared,sl_pre)) in
      let cp_post =
	let sl_post = spat_star new_nodes sl_transf_to_shared in
	env.g_prover.nf_cprop [] (cprop_spred sl_post) in
      let sl_local' = sl_transf_to_local @ sl_local in
      let sl_shared' = new_nodes @ (sl_transf_to_shared @ sl_rem_shared) in
      register_guarantee env.g_guar env.g_prover env.g_abstraction env.g_globals env.g_params 
        actlr rid cp_ctx cp_pre cp_post;
      let cf_shared' = ((pl_shared,sl_shared'),scpl') in
      Some [((pl_local,sl_local'), PCons (rid, cprop_cform cf_shared', scpl))]
    with Not_found -> None in
  let go_shared_wrapper rid cf_local (((pl_shared,_),_) as cf_shared) =
    let cp_local = env.g_prover.nf_cprop [] (cprop_cform (cf_local @% pl_shared)) in
    reduce_list (fun cf -> go_shared rid cf cf_shared) cp_local
  in
  let rec go_ctx rctx n =
    let (uf2,scpl2) = cform_of_eform n in
    match rctx with
    | [] -> None
    | rid::rctx ->
	try
	  let cp_shared = and_cprop_pure (PList.assq rid scpl2) (fst uf2) in
	  let cp_shared = List.fold
	    (fun (e1,_,_) cp -> env.g_prover.expose_ptsto cp e1)
	    assignl cp_shared in
	  let cp_local = (uf2, PList.remove_assq rid scpl2) in
	  match reduce_list (go_shared_wrapper rid cp_local) cp_shared with
	  | None -> go_ctx rctx n
	  | Some cp -> 
	      Some (ext_transform (fun _ -> cp) [n])
	with Not_found -> go_ctx rctx n in
  (* Local writes *)
  let go n =
    let ((pl2,sl2),scpl2) = cform_of_eform n in
    let sub = Pure.to_sub pl2 in
    try 
      let sl2 = List.fold_left (fun sl2 (e1,t,e2) ->
	let e1 = sub e1 in
	let (cel,sl2b) = env.g_prover.find_ptsto node_component e1 sl2 in
	let cel' = Fld.set t e2 cel in
	Csp_node(tag_default,node_component,e1,cel',tag2_default)::sl2b)
	sl2 assignl in
      let m = new_node ((pl2,sl2),scpl2) in
      put_edge_skip n m;
      Some [m]
    with Not_found ->
      if env.g_actinf then go_ctx rctx n else None in
  (* Main code *)
  reduce_list go cpre


(* -------------------------------------------------------------------------- *)
(** {2 Symbolic Execution} *)
(* -------------------------------------------------------------------------- *)

let implies_inv env cp inv =
  try 
    let _ = env.g_prover.find_frame_cprop [] 
              (List.map cform_of_eform cp) inv in 
    true
  with No_frame_found _ -> false

let rec epropl_or l1 l2 = match l1, l2 with
  | [], []     -> []
  | p1::l1, p2::l2 -> eprop_or p1 p2 :: epropl_or l1 l2
  | [], _ :: _ -> assert false
  | _ :: _, [] -> assert false

let rec eprop_nth_or n p0 l = match l with
  | p::l when n = 0 -> eprop_or p0 p :: l
  | p::l -> p :: eprop_nth_or (n-1) p0 l
  | [] -> assert false

(** Result of symbolic execution *)
type se_result = 
  { se_normal : eprop;
    se_break  : eprop list;
    se_cont   : eprop list;
    se_return : eprop }

(*
let se_false = 
  { se_normal = eprop_false; 
    se_break  = eprop_false;
    se_cont   = eprop_false;
    se_return = eprop_false }

let se_map f se = 
  { se_normal = f se.se_normal; 
    se_break  = f se.se_break;
    se_cont   = f se.se_cont;
    se_return = f se.se_return }
*)

type lv_data = 
  { lv_action : cprop list ; 
    lv_break  : eprop list ;
    lv_cont   : eprop list ;
    lv_return : eprop;
    lv_do_norm: bool;
    lv_kont   : can_cmd ;
  }

let ext_map f ep = ext_transform (fun cf -> f [cf]) ep

let kill_garbage prover lv ep1 =
  (if !verbose >= 4 then pp "lv=%a@." pp_idset lv); 
  ext_map
    (fun cf -> prover.nf_cprop [] cf
     |> kill_dead_vars lv
(*     |> kill_garbage_vars *)
     |> prover.nf_cprop [])
    ep1

let se_of_lvs lvs cp =
  { se_normal = cp;
    se_break  = lvs.lv_break;
    se_cont   = lvs.lv_cont;
    se_return = lvs.lv_return }

let add_missing_boxes env rgnl cp =
  let add_inv rid ((uf,scpl) as cf) = 
    if PList.mem_assq rid scpl then cf
    else (uf, PCons (rid, Hashtbl.find env.g_renv rid, scpl)) in
  ext_transform (fun cf -> [List.fold add_inv rgnl cf]) cp



let exit_pure_lin_unsat env res =
  if (env.g_linear_pre != None) && List.exists linear_bad_invariant res then begin
    if !verbose >= 1 then begin
      pp "The current resource invariant looks unpromising for proving linearizability.@.";
      List.iter (pp "BAD INV: %a@." pp_uform) (List.filter linear_bad_invariant res);
    end;
    raise Symbolic_execution_error  
  end


let mk_stab_env env =
  { st_prover = env.g_prover
  ; st_abstraction = env.g_abstraction
  ; st_lin_hook = exec_pure_lin_checker env
  ; st_lin_exit = exit_pure_lin_unsat env 
  }

let lvs_norm lvs =
  if lvs.lv_do_norm then lvs else {lvs with lv_do_norm = true}


let por_hack_possible env rid rely cp c =
  let por_hack_get c = match c with
    | {can_st_desc = Cst_fldassign(_,[(x,f,_)],_,_)} :: 
      {can_st_desc = Cst_stabilize(r)} :: _ when r==rid -> Some (x,f)
    | {can_st_desc = Cst_fldlookup(_,_,x,f,_) } :: 
      {can_st_desc = Cst_stabilize(r)} :: _ when r==rid -> Some (x,f)
    | _ -> None in
  match por_hack_get c with 
  | Some (x,f) ->
    (*List.iter (pp "PORaaa: %a@." pp_act) rely;*)
    let rely = act_changes x f rely in
    (*List.iter (pp "PORbbb: %a@." pp_act) rely;*)
    if !verbose > 3 then pp "Trying to perform POR@.";
    let get_shared rid (uf,scpl) =
      try PList.assq rid scpl with Not_found -> pp_internal_error (); assert false in
    let cp = List.map cform_of_eform cp in
    let b = 
      List.for_all (fun cf ->
        List.for_all (fun act -> 
          let cp_shared = get_shared rid cf in
          let cp_shared' = interfere_once env.g_prover act cp_shared in
          env.g_prover.entails_cprop cp_shared' cp_shared = []) rely)
        cp in
    if !verbose > 2 && b then pp "Performed POR@.";
    b
  | None -> false


let subst_params param_names params prop : cprop =
  let subs = PList.combine param_names params in
  map_cprop (mk_subst subs) prop


let escrow_precond env name params : cprop =
  let ei = Hashtbl.find env.g_esc_ht (string_of_component name) in
  subst_params ei.escrow_params params ei.escrow_pre


let escrow_postcond env name params : cprop =
  let ei = Hashtbl.find env.g_esc_ht (string_of_component name) in
  subst_params ei.escrow_params params ei.escrow_post


(** Collect all spatial predicates in [cf] in the form of [atomic[e->f,...]] *)
let collect_atomic_spreds (cf:cform) (e:exp) (f:component) : can_spred list * cform =
  let rec collect sl acc rest = match sl with
    | [] -> (acc,rest)
    | (Csp_atomic_fld(_,e',f',_,_) as sp)::sl when equal_exp e e' && f==f' -> collect sl (sp::acc) rest
    | sp::sl -> collect sl acc (sp::rest) in

  let (uf, plist) = cf in
  let (pure, spred_list) = uf in
  let (atomic_spreds, rest) = collect spred_list [] [] in
  (List.rev atomic_spreds, ((pure, rest), plist))


(** extract state proprosition *)
let pstate_prop pi (s:string) (params:exp list) (e:exp) : cprop =
  let (_, param_names, _, fv, prop) = StringMap.find s pi.protocol_states in
  debug "@.fv=%s, prop=%a@." (Id.to_string fv) pp_cprop prop;
  let subs = PList.cons fv e (PList.combine param_names params) in
  PList.iter (fun i e -> debug "%s -> %a@." (Id.to_string i) pp_exp e) subs;
  map_cprop (mk_subst subs) prop


let collect_duplicable_assertions (mo: read_memory_order) (cf:cform) : cform =
  let rec collect sl acc = match sl with
    | [] -> acc
    | (Csp_escrow _ as sp)::sl
    | (Csp_atomic_fld _ as sp)::sl -> collect sl (sp::acc)
    | _::sl -> collect sl acc in

  let ((p,sl),scpl) = cf in
  match mo with 
    | Crmo_nonatomic -> assert false
    | Crmo_relaxed -> ((p, spat_empty), PNil)
    | Crmo_acquire 
    | Crmo_seq_cst -> ((p, collect sl []), scpl)

let collect_escrows (cf:cform) : can_spred list * cform =
  let rec collect sl result remain = match sl with
    | [] -> (List.rev result, List.rev remain)
    | (Csp_escrow _ as sp)::sl -> collect sl (sp::result) remain
    | sp::sl -> collect sl result (sp::remain) in

  let (uf, plist) = cf in
  let (pure, spred_list) = uf in
  let (result, remain) = collect spred_list [] [] in
  (result, ((pure, remain), plist))


let rec discharge_escrows env subtract (p:cprop) = function
  | [] -> p
  | (Csp_escrow (_,name,params))::escl ->
      discharge_escrows env subtract (subtract p (escrow_postcond env name params)) escl
  | _ -> assert false


let unroll_escrow env subtract (cp:cprop) (escrow:can_spred) : cprop = match escrow with
  | Csp_escrow (_,name,params) ->
     begin
      let p = escrow_precond env name params in
      let q = escrow_postcond env name params in
      try cprop_star (subtract cp p) q
      with No_frame_found _ -> begin
        debug "@.unroll_escrow: cannot unroll@.  %a@.with cp=@.  %a@." pp_spred escrow pp_cprop cp;
        cprop_star cp (cprop_spred [escrow])
      end
     end
  | _ -> assert false


let unroll_escrows env subtract (cpre:cprop) : cprop =
  debug "@.unroll_escrows cpre=@.  %a@." pp_cprop cpre;

  let go (cf:cform) : cprop =
    let (escrows, cf) = collect_escrows cf in
    List.fold_left (unroll_escrow env subtract) (cprop_cform cf) escrows in

  let result = List.reduce_append go cpre in
  debug "@.unroll_escrows result=@.  %a@." pp_cprop result;
  result


let ghost_move_cform env subtract (p:cprop) (q:cform) : cprop =
  let (escl, q) = collect_escrows q in
  let p = discharge_escrows env subtract p escl in
  let q = cprop_cform q in
  try subtract p q
  with No_frame_found _ -> subtract (unroll_escrows env subtract p) q


(** returns [r] such that [p] ghost moves to [q*r], or raises No_frame_found *)
let ghost_move env subtract (p:cprop) (q:cprop) : cprop =
  debug "@.ghost_move@.  p: %a@.  q: %a@." pp_cprop p pp_cprop q;

  let rec go = function
    | []    -> raise (No_frame_found "ghost_move go")
    | [cf]  -> ghost_move_cform env subtract p cf
    | cf::q ->
        try ghost_move_cform env subtract p cf
        with No_frame_found _ -> go q in

  let r = go q in
  debug "@.ghost_move@.  r: %a@." pp_cprop r;
  r


let ghost_move env p q =
  let subtract = env.g_prover.find_frame_cprop [] in
  ghost_move env subtract p q


let ext_unroll_escrows env ep =
  ext_transform
    (fun cf -> unroll_escrows env (ghost_move env) (cprop_cform cf))
    ep


let ext_ghost_move env ep cq =
  ext_transform
    (fun cf -> ghost_move env (cprop_cform cf) cq)
    ep


let cprop_satisfiable (cp:cprop) : bool =
  List.exists
    (fun cf ->
      let pure = fst (fst cf) in
      let disjunts = Pure.normalize_aggr pure in
      List.length disjunts >= 1)
    cp


exception Break_fold_pstate_descendants

let rec fold_pstate_one_descendants depth pi (s:string) (params:exp list) params_prop visited f acc =
  let rec go names acc = match names with
    | [] -> acc
    | name::names' ->
        if StringSet.mem name visited then go names' acc else (* FIXME should allow every state to appear twice? *)
        let (_, succ_params, succ_predecessors, _, _) = StringMap.find name pi.protocol_states in
        let (_, pred_params, pred_prop) = List.find (fun (predname,_,_) -> predname=s) succ_predecessors in
        let succ_exps = List.map E.id (List.map Id.gensym_garb succ_params) in
        let subs = PList.rev_append (PList.combine succ_params succ_exps) (PList.combine pred_params params) in
        let pred_prop = map_cprop (mk_subst subs) pred_prop in
        let pred_prop = cprop_star params_prop pred_prop in
        let succ_prop_subst = pstate_prop pi name succ_exps in
        let prop_subst e = cprop_star pred_prop (succ_prop_subst e) in
        debug "@.depth=%d  succ_state=%s[%a]@." (depth+1) name pp_exp_list succ_exps;
        let acc = f (Pstate_one(component_of_string name,succ_exps)) prop_subst acc in
        let acc = fold_pstate_one_descendants (depth+1) pi name succ_exps pred_prop (StringSet.add name visited) f acc in
        go names' acc in

  let successor_state_names = StringMap.find s pi.protocol_successors in
  let successor_state_names = StringSet.elements successor_state_names in

  debug "@.# depth: %d" depth;
  debug "@.# state: %s[%a]" s pp_exp_list params;
  debug "@.# params_prop: %a" pp_cprop params_prop;
  debug "@.# visited:";
  StringSet.iter (fun s -> debug " %s" s) visited;
  debug "@.# successor_state_names:";
  List.iter (fun name -> debug " %s" name) successor_state_names;
  debug "@.";

  go successor_state_names acc

let fold_pstate_descendants pi (s:pstate) f acc = match s with
  | Pstate_one(s,params) ->
      let s = string_of_component s in
      debug "@.### fold_pstate_descendants %s[%a]@." s pp_exp_list params;
      fold_pstate_one_descendants 1 pi s params cprop_empty StringSet.empty f acc
  | Pstate_max(s1,s2) -> assert false (* TODO *)


let pstate_gensym_fv_ex pi (s:pstate) : Id.t = match s with
  | Pstate_one(s,_) ->
      let s = string_of_component s in
      let (_, _, _, fv, _) = StringMap.find s pi.protocol_states in
      Id.gensym_garb fv
  | Pstate_max _ -> assert false (* not implemented *)


let pstate_transitionable pi x y premise subtract = match x,y with
  | Pstate_one(x, x_params), Pstate_one(y, y_params) ->
     begin try
      let x = string_of_component x in
      let y = string_of_component y in
      let (_, y_param_names, y_predecessors, _, _) = StringMap.find y pi.protocol_states in
      let (_, pred_param_names, pred_prop) = List.find (fun (predname,_,_) -> predname=x) y_predecessors in
      let subs = PList.rev_append (PList.combine pred_param_names x_params) (PList.combine y_param_names y_params) in
      let pred_prop = map_cprop (mk_subst subs) pred_prop in
      subtract premise pred_prop; true
     with _ -> false end
  | _ -> false (* TODO *)


(** x = atomic_read(e->f,mo) *)
let execute_atomic_fld_lookup (env:global_env) (cpre:eprop) (x:Id.t) (e:exp) (f:component) (mo: read_memory_order) : eprop =
  debug "@.%s = atomic_read(%a->%s);@." (Id.to_string x) pp_exp e (string_of_component f);
  debug "@.precondition:@.  %a@." pp_eprop cpre;

  let sub = mk_gensym_garb_subst x in
  let cpre = map_eprop sub cpre in
  debug "@.after subst:@.  %a@." pp_eprop cpre;

  let mk_disjunct frame pi p (s:pstate) prop_subst acc =
    let st_prop = prop_subst (E.id x) in
    let frame = cprop_cform frame in
    let knowledge = List.map (collect_duplicable_assertions mo) (cprop_star st_prop frame) in
    let atom = cprop_spred [Csp_atomic_fld(tag_default,e,f,p,s)] in
    let disjunct = cprop_star atom (cprop_star frame knowledge) in
    cprop_or acc disjunct in

  let go eps cf : cprop =
    match collect_atomic_spreds cf e f with
      | [], _ ->
          begin match execute_fld_lookup env.g_prover [] x e f (eprop_of_cprop (cprop_cform cf)) with
            | None    -> raise Symbolic_execution_error
            | Some ep -> eps := ep::!eps; []
          end
      | [Csp_atomic_fld(_,_,_,p,s)], cf ->
          debug "@.frame:@.  %a@." pp_cform cf;
          let pi = Hashtbl.find env.g_pro_ht (string_of_component p) in
          fold_pstate_descendants pi s (mk_disjunct cf pi p) []
      | _ ->
          assert false (* should have at most one atomic spred *) in

  let eps = ref [] in
  let post = ext_transform (go eps) cpre in
  let post = List.fold_left eprop_or post !eps in
  debug "@.postcondition:@.  %a.@." pp_eprop post;
  post


(** release_write(x->f, e, p.s[params...]) *)
let execute_atomic_fld_assign (env:global_env) (cpre:eprop) (x:exp) (f:component) (e:exp) (p:component) (s:component) (params:exp list) : eprop =
  let p_str = string_of_component p in
  let s_str = string_of_component s in
  debug "@.release_write(%a->%s, %a, %s.%s[%a]);@." pp_exp x (string_of_component f) pp_exp e p_str s_str pp_exp_list params;
  debug "@.precondition:@.  %a@." pp_eprop cpre;

  let pi = Hashtbl.find env.g_pro_ht p_str in
  let st_prop = pstate_prop pi s_str params e in
  debug "@.st_prop:@.  %a@." pp_cprop st_prop;
  let s = Pstate_one(s, params) in

  let go_uninit precond =
    let uninit = cprop_spred [Csp_node(tag_default,node_component,x,Fld.emp,tag2_default)] in
    debug "@.uninit:@.  %a@." pp_cprop uninit;

    let conj = cprop_star uninit st_prop in
    debug "@.conj:@.  %a@." pp_cprop conj;

    let precond = cprop_cform precond in
    let frame = ghost_move env precond conj in
    debug "@.frame:@.  %a@." pp_cprop frame;

    let atom = cprop_spred [Csp_atomic_fld(tag_default,x,f,p,s)] in
    let postcond = cprop_star atom frame in
    debug "@.post:@.  %a@." pp_cprop postcond;
    postcond in

  let s'' = s in
  let go_init frame_p s =
    let frame_p = cprop_cform frame_p in
    let frame_q = ghost_move env frame_p st_prop in
    debug "@.frame_q:@.  %a@." pp_cprop frame_q;

    let iter_s'_descendants premise t _ _ =
      debug "@.t: %a" pp_pstate t;
      if pstate_transitionable pi t s'' premise (env.g_prover.find_frame_cprop []) then
        (debug "@.%a is transitionable to %a under premise %a" pp_pstate t pp_pstate s'' pp_cprop premise;
        raise Break_fold_pstate_descendants)
      else () in

    let iter_s_descendants s' s'prop_subst _ =
      debug "@.s': %a" pp_pstate s';

      let bar = E.id (pstate_gensym_fv_ex pi s') in
      let s'prop = s'prop_subst bar in
      debug "@.s'prop: %a" pp_cprop s'prop;
      debug "@.frame_p: %a" pp_cprop frame_p;

      let imply_premise = cprop_star s'prop frame_p in
      debug "@.imply_premise: %a" pp_cprop imply_premise;

      if cprop_satisfiable imply_premise then begin
        debug "@.satisfiable:@.  %a" pp_cprop imply_premise;
        try
          fold_pstate_descendants pi s' (iter_s'_descendants imply_premise) ();
          (* nothing happens *)
          debug "@.breaking second premise of release write rule: cannot reach s''=%a@." pp_pstate s'';
          raise Symbolic_execution_error
        with Break_fold_pstate_descendants -> ()
      end in

    debug "@.s: %a" pp_pstate s;
    fold_pstate_descendants pi s iter_s_descendants ();
    debug "@.end of iter_s_descendants@.";

    let atom = cprop_spred [Csp_atomic_fld(tag_default,x,f,p,s'')] in
    let postcond = cprop_star atom frame_q in
    debug "@.post:@.  %a@." pp_cprop postcond;
    postcond in

  let go cf = match collect_atomic_spreds cf x f with
    | [], _ -> go_uninit cf
    | [Csp_atomic_fld(_,_,_,p',s)], cf ->
        if p==p' then go_init cf s else
        raise Symbolic_execution_error (* incompatible protocol *)
    | _ -> assert false in

  ext_transform go cpre



(** x = CAS(e->f, vo, vn, mo_success, mo_failure) *)
let execute_cas (env:global_env) (cpre:eprop) (x:Id.t) (e:exp) (f:component) (vo:exp) (vn:exp) 
                (mo_success: cas_memory_order) (mo_failure : read_memory_order) : eprop =
  debug "@.%s = CAS(%a->%s, %a, %a);@." (Id.to_string x) pp_exp e (string_of_component f) pp_exp vo pp_exp vn;
  debug "@.precondition:@.  %a@." pp_eprop cpre;
  assert (mo_success = Ccmo_seq_cst || mo_success = Ccmo_rel_acq);

  let (@*) = cprop_star in
  let sub = mk_gensym_garb_subst x in
  let cpre = map_eprop sub cpre in
  debug "@.after subst:@.  %a@." pp_eprop cpre;

  let success_pure = Pure.one (E.eq (E.id x) E.one) in
  let success_prop = cprop_pure success_pure in

  let success' pi p c1 s'' s''prop_subst (found,acc) =
    let c2 = s''prop_subst vn in
    try
      let q = ghost_move env c1 c2 in
      let atom = cprop_spred [Csp_atomic_fld(tag_default,e,f,p,s'')] in
      let disjunct = atom @* success_prop @* q in
      (true, cprop_or acc disjunct)
    with No_frame_found _ -> (found,acc) in

  let success cf pi p s' s'prop_subst (acc:cprop) =
    let c1 = (s'prop_subst vo) @* (cprop_cform cf) in
    let (found,acc) = fold_pstate_descendants pi s' (success' pi p c1) (false,acc) in
    if found then acc else begin
      debug "@.no descendant found for %a@." pp_pstate s';
      raise Symbolic_execution_error
    end in

  let failure_pure = Pure.one (E.eq (E.id x) E.zero) in
  let failure_prop = cprop_pure failure_pure in

  let failure cf pi p s'' s''prop_subst (acc:cprop) =
    let frame_p = cprop_cform cf in
    let y = Id.gensym_str_ex "y" in
    let y = E.id y in
    let y_ne_vo = cprop_pure (Pure.one (E.neq y vo)) in
    let premise = y_ne_vo @* (s''prop_subst y) @* frame_p in
    let r = List.map (collect_duplicable_assertions mo_failure) premise in
    let atom = cprop_spred [Csp_atomic_fld(tag_default,e,f,p,s'')] in
    let disjunct = atom @* failure_prop @* frame_p @* r in
    cprop_or acc disjunct in

  let go cf : cprop =
    match collect_atomic_spreds cf e f with
      | [], _ ->
          raise Symbolic_execution_error (* no atomic[...] found *)
      | [Csp_atomic_fld(_,_,_,p,s)], cf ->
          let pi = Hashtbl.find env.g_pro_ht (string_of_component p) in
          debug "@.executing success...@.";
          let cq = fold_pstate_descendants pi s (success cf pi p) [] in
          debug "@.executing failure...@.";
          let cq = fold_pstate_descendants pi s (failure cf pi p) cq in
          debug "@.post:@.  %a@." pp_cprop cq;
          cq
      | _ ->
          assert false (* should have at most one atomic spred *) in

  ext_transform go cpre

(** The main symbolic execution function *)
let rec symb_execute (env : global_env) (c : can_cmd) (lvs : lv_data) (cpre : eprop) : se_result =
  let opt_kill_garb c0 cp =
    if lvs.lv_do_norm then kill_garbage env.g_prover c0.can_st_lv cp else cp in
  (* Output current symbolic execution state *)
  let _ =
    if !verbose >= 4 then
      let pp_comp s f ep = 
        if ep=[] then () else Format.fprintf f "  %s: %a@." s pp_eprop ep in
      let rec pp_compl s n f epl = 
        match epl with 
        | [] -> ()
        | [] :: epl -> pp_compl s (n+1) f epl
        | ep :: epl -> Format.fprintf f "  %s(%d): %a@." s n pp_eprop ep;
                       pp_compl s (n+1) f epl in
      match c with
	| {can_st_loc = loc1}::_ ->
            let cpre = List.map cform_of_eform cpre in
            let cpre = if !debug_lf > 0 then
                and_cprop_pure cpre (Pure.one (E.eq (E.id (Id.level !debug_lf)) E.zero))
              else cpre in
	    print loc1 "Intermediate State:@.%a%a[@[%a@]]@.%a@."
              (pp_comp "return") lvs.lv_return (* (pp_compl "break" 0) lvs.lv_break *)
              (pp_compl "continue" 0) lvs.lv_cont pp_cprop cpre pp_cmd c
	| _ -> () in
  (* If the precondition is satisfiable, proceed with symbolic execution *)
  match cpre with [] -> se_of_lvs lvs eprop_false | _ -> 
  match c with [] -> se_of_lvs lvs cpre | c0 :: c1 ->
  match c0.can_st_desc with 
    | Cst_nondet (c2,c3) ->
	let cpre = opt_kill_garb c0 cpre in
	let (cp2,cp3) = ext_append_case_split cpre in
        let lvs = { lvs with lv_do_norm = false } in
	let sq2 = symb_execute env c2 lvs cp2 in
	let sq3 = symb_execute env c3 lvs cp3 in
	let lvs = 
	  { lvs with 
              lv_kont   = c1;
              lv_do_norm = true;
	      lv_break  = epropl_or sq2.se_break  sq3.se_break;
	      lv_cont   = epropl_or sq2.se_cont   sq3.se_cont;
	      lv_return = eprop_or sq2.se_return sq3.se_return } in
	let cq = eprop_or sq2.se_normal sq3.se_normal in
	symb_execute env c1 lvs cq
    | Cst_kill ids ->
	(*TODO let cpre = ext_append_assign (IdSet.fold (fun i r -> (i,None)::r) ids []) cpre in *)
	let cq = naive_map_eprop (mk_gensym_garb_subst_idset ids) cpre in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_assign (x,e) ->
	(* let cpre = if do_norm then kill_garbage env.g_prover c0.can_st_lv cpre else cpre in *)
	let cp = ext_append_assign [(x,Some e)] cpre in
	let sub = mk_gensym_garb_subst x in
	let cq = E.eq (E.id x) (sub e) @@& (map_eprop sub cp) in
	symb_execute env c1 { lvs with lv_do_norm = true } cq
    | Cst_fldlookup (rgnl,x,e,t,Crmo_nonatomic) ->
	let cpre = opt_kill_garb c0 cpre in
        let cpre = add_missing_boxes env rgnl cpre in
	let cp = ext_append_assign [(x,None)] cpre in
	let cq = match execute_fld_lookup env.g_prover rgnl x e t cp with
	  | Some cq -> cq
	  | None ->
              let cp = ext_unroll_escrows env cp in
              match execute_fld_lookup env.g_prover rgnl x e t cp with
                | Some cq -> cq
                | None -> error_heap c0.can_st_loc e cpre in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_fldlookup ([],x,e,f,mo) ->
	(* x = atomic_read(e->f,mo) *)
	let cq = execute_atomic_fld_lookup env cpre x e f mo in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_fldlookup _ -> assert false (* not implemented *)
    | Cst_fldassign (rgnl,l,actlr,Cwmo_nonatomic) ->
	let cpre = opt_kill_garb c0 cpre in
        let cpre = add_missing_boxes env rgnl cpre in
	let cp = List.fold (fun (e,_,_) cp -> ext_expose_ptsto env.g_prover e cp) l cpre in
	let cq = match execute_fld_assign env actlr rgnl l cp with
	  | Some cq -> cq
	  | None -> error_heap2 c0.can_st_loc "memory write" cpre in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_fldassign ([],[(x,f,e)],_,Cwmo_release(Some (p,s,params))) ->
	(* release_write(x->f, e, p.s[params...]) *)
	let cq = execute_atomic_fld_assign env cpre x f e p s params in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_fldassign _ -> assert false (* not implemented *)
    | Cst_cas ([],x,e,f,vo,vn,mos,mof) ->
        (* x = CAS(e->f, vo, vn) *)
        let cq = execute_cas env cpre x e f vo vn mos mof in
        symb_execute env c1 (lvs_norm lvs) cq
    | Cst_cas _ -> assert false (* not implemented *)
    | Cst_new (x,size) ->
(* assert (size == E.one);*) (* TODO !!!!!!!!! *)
	(* let cpre = if do_norm then kill_garbage env.g_prover c0.can_st_lv cpre else cpre in *)
	let cp = ext_append_assign [(x,None)] cpre in
	let cq = 
	  let sub = mk_gensym_garb_subst x in
	  let cp = map_eprop sub cp in
          let cq0 = cprop_uform
              (mk_array tag_default (E.id x) (E.add (E.id x) size) 
                        (E.id (Id.gensym_str_ex "VAL")) Fld.emp Dset.emp uform_empty) in
	  (*let cq0 = cprop_spred [Csp_node(tag_default,node_component,E.id x,Fld.emp)] in*)
	  cq0 @@*** cp in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_dispose (e,size) ->
        assert (size == E.one); (* TODO !!!!!!!!! *)
	let cpre = opt_kill_garb c0 cpre in
	let cp1 = cprop_spred [Csp_node(tag_default,node_component,e,Fld.emp,tag2_default)] in
	let cq = execute_gen_cmd (ext_subtract env.g_prover) (IdSet.empty,cp1,cprop_empty,"dispose",c0.can_st_loc) cpre in
	symb_execute env c1 { lvs with lv_do_norm = false } cq (* Already normalized *)
    | Cst_pfcall par_calls ->
	let cpre = opt_kill_garb c0 cpre in
	  (* TODO -- freshen exist. vars *)
	  let cp =
	    List.fold
	      (fun (_,s,_,_,_) cp ->
		 if str_is_cutpoint s then
		   ext_append_comment 
		     (fun () ->
			let n = next_cutpoint() in
			"goto " ^ n ^ "; " ^ n ^ ": 0;") cp
		 else if str_is_fair s then 
		   ext_append_comment (fun () -> s ^ " = 1;") cp
		 else cp) par_calls cpre in
	  (* 1. Calculate the specification of a generic command *)
          let go_fun (resido,s,_,idl,el) =
	    let fi = Hashtbl.find env.g_fun_ht s in
	    let (vl,idl) = match resido with
	      | None -> (fst fi.fun_param, idl)
	      | Some resid -> (Id.create "Result" :: fst fi.fun_param, resid :: idl) in
	    let sub = 
	      let sl_ref = PList.combine vl (List.map E.id idl) in
	      let sl_val = PList.combine (snd fi.fun_param) el in
	      mk_subst (PList.rev_append sl_ref sl_val) in
	    let modif = List.fold IdSet.add idl (map_idset sub fi.fun_modif) in
	    let (sub_ex, sub_ex_post) = 
	      let exfv_pre = prop_exfv fi.fun_pre IdSet.empty in
	      let exfv_post = IdSet.diff (prop_exfv fi.fun_post IdSet.empty) exfv_pre in
	      (mk_gensym_garb_subst_idset exfv_pre,
	       existentials_rename_sub exfv_post) in
            let post = map_cprop (fun e -> sub_ex_post (sub_ex (sub e))) fi.fun_post in
	    let pre = map_cprop (fun e -> sub_ex (sub e)) fi.fun_pre in
	    (modif,pre,post) in
	  let go (m,p,q) x =
	    let (m',p',q') = go_fun x in
	    (IdSet.union m' m, cprop_star p' p, cprop_star q' q) in
          let (modif,cp1,cp2) = List.fold_left go (IdSet.empty,cprop_empty,cprop_empty) par_calls in
	  (* 2. Apply the generic command *)
	  let cq = execute_gen_cmd (ext_ghost_move env) (modif,cp1,cp2,"Function call",c0.can_st_loc) cp in 
	  symb_execute env c1 (lvs_norm lvs) cq
    | Cst_fcall2 (modif,cp1,cp2,s') ->
	let cpre = opt_kill_garb c0 cpre in
	let cq = execute_gen_cmd (ext_ghost_move env) (modif,cp1,cp2,s',c0.can_st_loc) cpre in 
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_assume cp ->
	let cq = cp @@*** cpre in
	let cq = ext_transform normalize_cform_aggr cq in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_assume_exp e ->
	let cq = cprop_pure (Pure.one e) @@*** cpre in
	let cq = ext_transform normalize_cform_aggr cq in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_assert_exp e ->
        let _ = if not (env.g_prover.adv_entails_atom (List.map cform_of_eform cpre) e) then
          error_noframe_ext c0.can_st_loc "assert" cpre (cprop_pure (Pure.one e)) in
	symb_execute env c1 (lvs_norm lvs) cpre
    | Cst_action_begin (rid,cp_ctx,cp0,cq0,modif_body) ->
	let cpre = opt_kill_garb c0 cpre in
	  let (cp,cp_ctx,cp0,lvs') =
	    (* 1. Freshen existential variables *)
	    let (cp_ctx,cp0,cq0) =
	      let (@+) = prop_exfv in
	      let exfv = (cp0 @+ cq0 @+ cp_ctx @+ IdSet.empty) in
	      let sub = mk_gensym_garb_subst_idset exfv in
	      (map_cprop sub cp_ctx, map_cprop sub cp0, map_cprop sub cq0) in
	    (* 2. Rename vars modified by region body and appear in action post *)
	    let (cp,cq0) =
	      let sub_modif_pairs = 
		let modif_vars = IdSet.inter modif_body (fv_norm_cprop cq0) in
		IdSet.fold (fun id r -> PCons(id, E.id (Id.gensym_norm id), r)) modif_vars PNil in
	      let cq0 = map_cprop (mk_subst sub_modif_pairs) cq0 in
	      let pl' = PList.fold (fun id e res-> E.eq (E.id id) e @& res) 
		sub_modif_pairs Pure.ptrue in
	      let cp = pl' @@&& cpre in
	      (cp,cq0) in
	    let lvs' = { lvs with lv_do_norm = true; lv_action = cq0 :: lvs.lv_action } in
	    (cp,cp_ctx,cp0,lvs') in
	  (* Consider each disjunct separately *)
	  let cq = ext_transform (fun cf ->
	      (* 1. Calculate the frame [fr] that is not accessed by the block *)
	      let fr = 
		let cp_shared = try
                    PList.assq rid (snd cf) 
                  with Not_found -> pp_internal_error (); assert false in
		let cp1 = and_cprop_pure cp_shared (fst(fst cf)) in           
		try env.g_prover.find_frame_cprop (snd(fst cf)) cp1 cp0
		with No_frame_found _ -> 
		  error_noframe c0.can_st_loc "action entry" cp1 cp0 in
	      (* 2. Check that the frame [fr] contains the context: [fr |- cp_ctx * true] *)
              let _ = 
		try 
		  let (sub1,sub2) = existentials_rename_tonormal_sub (prop_exfv fr IdSet.empty) in
		  let fr = map_cprop sub1 fr in
		  let cp_ctx = map_cprop sub1 cp_ctx in
		  env.g_prover.find_frame_cprop (snd(fst cf)) fr cp_ctx
		with No_frame_found _ ->
		  error_noframe c0.can_st_loc "action entry context" fr cp_ctx in
	      (* 3. Calculate the precondition inside the block *)
	      let cfl = 
		let uf = fst cf in
		let scpl' = PList.remove_assq rid (snd cf) in
		List.map (fun cfs -> (uf, PCons(rid, cprop_cform cfs, scpl'))) fr
	      in
	      cprop_star cfl cp0) cp in
	  symb_execute env c1 lvs' cq
    | Cst_action_end (rid,_) ->
	let cpre = opt_kill_garb c0 cpre in
	(* 1. Pop the action's postcondition from the stack *)
	let (cq0, lvs) =
	  (List.hd (lvs.lv_action), {lvs with lv_do_norm=true; lv_action = List.tl (lvs.lv_action)}) in
	(* 2. Calculate the postcondition outside the "do" block *)
	let modif_body = IdSet.empty (* TODO! *) in 
	let cq = exit_from_block env.g_prover (rid,modif_body,cq0,c0.can_st_loc) cpre in
	symb_execute env c1 lvs cq
    | Cst_interfere (rid,actid) ->
	let cpre = opt_kill_garb c0 cpre in
	let get_shared rid (uf,scpl) = try
	  ((uf, PList.remove_assq rid scpl), PList.assq rid scpl)
	with Not_found -> pp_internal_error (); assert false in
	let act = 
	  try
	    List.find (fun a -> act_name a = actid) (fst (Hashtbl.find env.g_res_ht rid))
	  with Not_found -> pp_internal_error (); assert false in
	let cq = ext_transform
	  (fun cf ->
	     let ((uf,scpl),cp_shared) = get_shared rid cf in
	     let cp_shared = interfere_once env.g_prover act cp_shared in
	     cprop_cform (uf, PCons (rid, cp_shared, scpl)))
	  cpre in
	symb_execute env c1 (lvs_norm lvs) cq
    | Cst_stabilize(rid) ->
	if env.g_no_interf_hack then symb_execute env c1 lvs cpre
	else
	  let cpre = opt_kill_garb c0 cpre in
	  let (_,rely) = Hashtbl.find env.g_res_ht rid in
          let senv = mk_stab_env env in
          let cq =
            if env.g_por_hack && por_hack_possible env rid rely cpre (c1 @ lvs.lv_kont) then cpre
            else stabilize senv (rid,rely) cpre in
	  Gc.minor ();
	  let _ = (* Debugging... *)
	    let inv = [(uform_empty, PCons (rid, Hashtbl.find env.g_renv rid, PNil))] in
	    if not (implies_inv env cq inv) && implies_inv env cpre inv
	    then begin
	      if !verbose > 0 then 
	        pp "@.WARNING: Loss of precision@.";
              if !verbose > 2 then
                pp "BEFORE = %a@.AFTER = %a@." pp_eprop cpre pp_eprop cq;
              (*Prover.verbose := 100;
              let cp = List.map cform_of_eform cpre |>  List.filter 
                (fun cf -> try let _ = env.g_prover.find_frame_cprop [] [cf] inv in true with No_frame_found _ -> false) in
              let cq = List.map cform_of_eform cq |> List.filter 
                (fun cf -> try let _ = env.g_prover.find_frame_cprop [] [cf] inv in true with No_frame_found _ -> false) in
	      assert false;
              pp "Failing assertions:@.BEFORE = %a@.AFTER = %a@." pp_cprop cp pp_cprop cq *)
	    end in
	  symb_execute env c1 (lvs_norm lvs) cq
    | Cst_loop(c2,None) ->
	let cpre = opt_kill_garb c0 cpre in
	(* Cell to store the exit conditions *)
	let res_break = ref (eprop_false :: lvs.lv_break) in
	let res_cont = ref (eprop_false :: lvs.lv_cont) in
	let res_return = ref eprop_false in
	let lvs' = 
          { lv_do_norm = false;
            lv_action = lvs.lv_action;
	    lv_break = eprop_false :: lvs.lv_break; 
            lv_cont = eprop_false :: lvs.lv_cont;
            lv_return = eprop_false ;
            lv_kont = c2 } in
	let transf cp =
	  let (cp,_) = ext_append_case_split cp in
          let se = symb_execute env c2 lvs' cp in
	  res_break  := epropl_or se.se_break  !res_break;
	  res_cont   := epropl_or se.se_cont   !res_cont;
	  res_return := eprop_or se.se_return !res_return;
	  kill_garbage env.g_prover c0.can_st_lv (eprop_or se.se_normal (List.hd se.se_cont)) in
	let pre = 
	  (* HACK: First calculate a fixpoint assuming no interference occurs *)
	  if not env.g_no_interf_hack then begin
	    let fix = compute_transf_fixpoint {env with g_no_interf_hack = true} transf cpre c0.can_st_loc in 
	    fix
	  end else cpre in
	  (* 1. Compute fixpoint *)
	  let _ = compute_transf_fixpoint env transf pre c0.can_st_loc in
	  let (_,cq,_) = env.g_abstraction.prop_join eprop_false eprop_false (List.hd !res_break) in
	  let lvs = { lvs with lv_do_norm = true ;
                               lv_return = eprop_or !res_return lvs.lv_return;
                               lv_break = List.tl !res_break ;
                               lv_cont  = List.tl !res_cont  } in
	  (* 2. Return the result *)
	  symb_execute env c1 lvs cq
    | Cst_loop(c2,Some inv) ->
	let cpre = opt_kill_garb c0 cpre in
	  let inv0 = eprop_of_cprop inv in
	  (* 1. Check precondition entails loop invariant *)
	  let fr = 
	    try ext_ext_subtract env.g_prover cpre inv0
	    with No_frame_found _ -> error_noframe_ext c0.can_st_loc "loop entry" cpre inv in
	  (* 2. Execute the body of the loop *)
	  let lvs' = 
             { lv_do_norm = true;
               lv_action = lvs.lv_action;
	       lv_break  = eprop_false :: lvs.lv_break; 
               lv_cont   = eprop_false :: lvs.lv_cont; 
               lv_return = eprop_false ; 
               lv_kont   = c2 } in
	  let se = symb_execute env c2 lvs' inv0 in
	  (* 3. Check postcondition of the loop body entails loop invariant *)
	  let () = 
	    let cq = eprop_or (List.hd se.se_cont) se.se_normal in
	    let fr' =
	      try ext_ext_subtract env.g_prover cq inv0
	      with No_frame_found _ -> error_noframe_ext c0.can_st_loc "loop exit" cq inv in
	    test_leakmem c0.can_st_loc fr' in
	  (* 4. Calculate the postcondition of the loop *)
	  let cq = fr @@*** List.hd se.se_break in
	  let lvs = { lvs with lv_do_norm = true;
                               lv_return = eprop_or (fr @@*** se.se_return) lvs.lv_return ;
                               lv_break = List.tl (se.se_break) ;
                               lv_cont  = List.tl (se.se_cont) } in
	  symb_execute env c1 lvs cq
    | Cst_goto (Cgo_break n) ->
        let cpre = kill_garbage env.g_prover c0.can_st_lv cpre in
	let cpre = ext_transform normalize_cform_aggr cpre in
        let _ = 
          if !verbose >= 3 && not (Genarith.enabled ()) && not env.g_no_interf_hack then 
	    pp "@.BREAK ADDING (%s):@.%a@." (Location.lineno_to_string c0.can_st_loc)
              pp_eprop cpre in
        let nbr = eprop_nth_or n cpre lvs.lv_break in
        let _ = 
          if !verbose >= 3 && not (Genarith.enabled ()) && not env.g_no_interf_hack then 
	    pp "@.BREAK TOTAL (%s):@.%a@." (Location.lineno_to_string c0.can_st_loc)
              pp_eprop (List.nth nbr n) in
	{ se_normal = eprop_false; 
	  se_break  = nbr ;
	  se_cont   = lvs.lv_cont ;
	  se_return = lvs.lv_return }
    | Cst_goto (Cgo_continue n) ->
	{ se_normal = eprop_false; 
	  se_break  = lvs.lv_break ; 
	  se_cont   = eprop_nth_or n cpre lvs.lv_cont ;
	  se_return = lvs.lv_return }
    | Cst_goto (Cgo_return) ->
	{ se_normal = eprop_false; 
	  se_break  = lvs.lv_break ; 
	  se_cont   = lvs.lv_cont ;
	  se_return = eprop_or cpre lvs.lv_return }
    | Cst_comment s ->
	let cq = ext_append_comment (fun () -> s) cpre in
	symb_execute env c1 lvs cq

let calculate_post (env : global_env) cp1 c fv_post =
  let se =
    let lvs =
      { lv_do_norm = true;
        lv_action = [];
        lv_break = [];
        lv_cont = [];
        lv_return = eprop_false ; lv_kont = [] } in
    symb_execute env c lvs cp1 in
  assert (se.se_break = []); (* allowed only in a loop *)
  assert (se.se_cont = []);  (* allowed only in a loop *)
  kill_garbage env.g_prover fv_post
    (eprop_or se.se_return se.se_normal)

let check_resource env (rid,what) =
  env.g_linear_pure_code <- [];
  pp_comment ("Resource " ^ string_of_component rid);
  let (_,rely) = Hashtbl.find env.g_res_ht rid in
  try match what with
    | Cri_inv (inv,loc) ->
	let inv = env.g_prover.nf_cprop [] inv in
  	Hashtbl.add env.g_renv rid inv;
	let inv' = make_stable (mk_stab_env env) inv rely in
	let fr =
	  try env.g_prover.find_frame_cprop [] inv' inv
	  with No_frame_found _ -> error_noframe loc "resource invariant" inv' inv  in
	test_leakmem ~warn:false loc fr;
	true
    | Cri_code (fv_post,c,loc) ->
  	Hashtbl.add env.g_renv rid cprop_empty;
	let cp = eprop_of_cprop cprop_empty in
	let cq = calculate_post env cp c fv_post in
	let cq = List.map cform_of_eform cq in
	let cq = 
	  let fv = IdSet.diff (prop_fv cq IdSet.empty) fv_post in
	  let sub = mk_gensym_garb_subst_idset fv in
	  map_cprop sub cq in
	let cq = match env.g_linear_pre with
	  | None -> cq
	  | Some cpre -> cprop_star cpre cq in
	let inv = make_stable (mk_stab_env env) cq rely in
	if !verbose >= 2 && not (Genarith.enabled ()) then
	  pp "@.FOUND RESOURCE INVARIANT:@.%a@." pp_cprop inv;
	Hashtbl.replace env.g_renv rid inv; true
  with Symbolic_execution_error -> false


let expand_cform (uf, scpl) = 
  PList.fold 
    (fun s cp r -> List.reduce_append (fun scpl -> List.map (fun cf -> PCons(s,[cf],scpl)) cp) r)
    scpl [PNil]
  |> List.map (fun scpl -> (uf,scpl))


let check_entailment env (fname,(cp1,c,pure_code,cp2,post_lv,loc)) =
  let pure_code = if !disable_pure_code_checking then [] else pure_code in
  let params = (Hashtbl.find env.g_fun_ht fname).fun_param in
  let params = List.fold IdSet.add (snd params) IdSet.empty in
  env.g_params <- IdSet.add Id.result params; (** VV: hack for action abstraction *)
  env.g_linear_pure_code <- pure_code;
  if str_is_cutpoint fname then true
  else if str_is_fair fname then
    if Genarith.enabled () then
      (pp "@.int %s = 0;@." fname; true)
    else 
      (pp "@.WARNING: Ignoring function %s@." fname; true)
  else begin
    pp_comment ("Function " ^ fname);
    (if !verbose >= 3 && pure_code != [] then
       pp "@.Pure checker:@.  %a@." pp_cmd pure_code);
    (* Normalize the precondition and the postcondition *)
    let cp1 = env.g_prover.nf_cprop [] cp1 in
    let cp2 = env.g_prover.nf_cprop [] cp2 in
    if !verbose >= 3 then
      pp "@.VERIFICATION CONDITION:@.[@[%a@]]@.%a@.[@[%a@]]@.@."
	pp_cprop cp1 pp_cmd c pp_cprop cp2;
    try 
      (* 1. Create entry and exit node(s) for the arithmetic program *)
      let (n1,ep1) = eprop_of_cprop_at_start_node cp1 in
      let ep2 = eprop_of_cprop cp2 in
      ext_append_return ep2;
      (* 2. Execute the body *)
      let cq = calculate_post env ep1 c post_lv in
      let cq = plain_ext_transform expand_cform cq in
      if !verbose >= 4 then pp "@.Derived postcondition:@.%a@." pp_eprop cq;
      (* 3. Check the postcondition *)
      let fr =
	try ext_ext_subtract env.g_prover cq ep2
	with No_frame_found _ -> error_noframe_ext loc "postcondition" cq cp2 in
      test_leakmem loc fr             (* Are there any memory leaks? *) ;
      pp_generated_function fname n1  (* Output integer program *) ;
      true
    with Symbolic_execution_error -> false
  end

(** Check VCs without doing action inference. *)
let check_no_inference env ril entl =
  env.g_actinf <- false; 
  List.for_all (check_resource env) ril
  && List.for_all (check_entailment env) entl

(** Check VCs without doing action inference. *)
let infer_actions_once env ril entl =
  env.g_actinf <- true; 
  List.for_all (check_resource env) ril
  && List.for_all (check_entailment env) entl

let cprop_common_pure (cp : cprop) = 
  let rec do_common p cp = match cp with 
    | [] -> cprop_pure p
    | ((p',_),_)::cp -> do_common (Pure.common p p') cp in
  match cp with 
   | [] -> []
   | ((p,_),_)::cp -> do_common p cp
  

(** Executes RGSep action inference. *)
let rec infer_actions env ril entl =
  let rec go2 n =
    pp_line ();
    if n >= 10 then begin 
      if !verbose >= 1 then pp "@.ERROR: Exceeding number of allowed iterations.@.";
      false
    end else begin
      actlr_clear entl;
      Hashtbl.clear env.g_renv;
      update_res_ht env.g_guar env.g_res_ht;
      if !verbose >= 1 then pp "Iter: %d, #Actions: %d@." n (List.length env.g_guar.ge_actions);
      if !verbose >= 2 then pp_actions env.g_guar.ge_actions;
      infer_actions_once env ril entl
      && if env.g_guar.ge_changed then begin
	go2 (n+1)
      end else begin
	pp_line ();
	if !verbose >=1 then pp "DONE after iteration: %d@." n;
	if !verbose >= 2 || !remember_result_hack then begin 
	  pp "@.Inferred %d actions:@." (List.length env.g_guar.ge_actions);
	  pp_actions env.g_guar.ge_actions;
	  if !remember_result_hack then actlr_upd cprop_common_pure entl;
	  actlr_print entl;
	  Hashtbl.iter
	    (fun r inv ->
	       pp "@.Invariant of resource %s:@.  %a@." (string_of_component r) pp_cprop inv)
	    env.g_renv
	end;
	true
      end
    end in
  go2 1

