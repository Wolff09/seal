(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)
(** Lock-freedom prover *)
open Misc
open Exp
open Assertions
open Commands
open Genarith
open Actions
open Symbsimp

(* -------------------------------------------------------------------------- *)
(** {2 Shorthands} *)
(* -------------------------------------------------------------------------- *)

let (@%) ((pl,sl),scpl) pl' = ((Pure.conj pl' pl,sl),scpl)
let (@&) = Pure.conj_one
let (@@***) x y = eprop_star_assume x y
let (@@**) x y = eprop_star x y
let (@@&&) x y = cprop_pure x @@** y
let (@@&)  x y = Pure.one x @@&& y

let print loc = Location.print (!Misc.formatter) loc; pp 

let pp_generated_function fname n =
  if Genarith.enabled () then pp_function !Misc.formatter (fname,n)

let cform_to_sub ((p,_),_) = Pure.to_sub p

(* -------------------------------------------------------------------------- *)
(** {2 Lock-freedom prover} *)
(* -------------------------------------------------------------------------- *)

(**
  Inputs: 
  - [env] : environment containing (among other things) the set of actions
            inferred.
  - [ril] : initialization code
  - [entl] : a list of [{P}C{Q}] 'entailments' (one for each method).

  Now, for each field assignment, [Cst_fldassign(rl,assnl,actlr,mo)], inside
  the entailments, [entl], the earlier pass has annotated an action [R|P~>Q]
  in [env] together with a substitution for certain free variables.

  Proposed strategy:

  1. For each annotated action, calculate the loop depth within which it
     appears.

     e.g.    loop  (A ; loop ( B  +  (C ; break ) ) ) ; D
 
     A -> 1 ;  B -> 2 ;  C -> 1 ;  D -> 0 

  2.  Augment these actions with asserting that the level_loopdepth is 1 

     i.e. if an action R | P ~> Q is used at loop depth K, change it
     to  R * (level_(K + 1) = 1) * (level_(k + 2) = 1) * ... * (level_(N) = 1) | P ~> Q.
     
     i.e. if an action  R | P ~> Q is followed by a break at loop depth K, change it
     to  R * (level_(K) = 1) * (level_(k + 1) = 1) * ... * (level_(N) = 1) | P ~> Q.
     
  3. Change each loop to add checks that the Level_loopdepth is 1.

     i.e. given a loop at depth K, change it as follows:

      loop (  C  )    -->    loop ( level_K = * ; C ; assert(level_K = 1) ).


*)

(** Adjuct the current loop depth because of a possible break statement. *)
let rec adj_loop_depth cc k adjk = match cc with
  | [] -> adjk 
  | c::cc ->
      match c.can_st_desc with
        | Cst_goto (Cgo_break n)    -> (k - n - 1)
        | Cst_goto (Cgo_continue n) -> (k - n)
        | Cst_goto  Cgo_return      -> 0
        | _ -> adj_loop_depth cc k adjk

(** Calculate the maximum loop depth of the program and of each action *)
let rec caldepth (entl:(string * can_entailment) list) envl =
 
  let max (a:int) (b:int) : int = if a > b then a else b in

  let upd_act_level_name_one k (name:string) ((((_,(actid,_,_,_,_)) as act), d) as p) =
    if Pervasives.(=) name actid && d < k then (act, k) else p in

  let upd_act_level k l (name,_) = List.map (upd_act_level_name_one k name) l in

  let rec calc_depth_cmd cc k adjk l = match cc with
    | [] -> (k, l)
    | c::cc ->
        match c.can_st_desc with
          | Cst_fldassign (rgnl, _, actlr, _) ->
              let l = List.fold_left (upd_act_level adjk) l !actlr in
              calc_depth_cmd cc k adjk l 
          | Cst_loop (body, inv) ->
              let adjk' = adj_loop_depth body (k+1) (adjk+1) in
              let (db, l) = calc_depth_cmd body (k+1) adjk' l in
              let (dc, l) = calc_depth_cmd cc k adjk l in
              (max db dc, l)
          | Cst_nondet (c1, c2) ->
              let (d1, l) = calc_depth_cmd c1 k (adj_loop_depth c1 k adjk) l in
              let (d2, l) = calc_depth_cmd c2 k (adj_loop_depth c2 k adjk) l in
              let (dc, l) = calc_depth_cmd cc k adjk l in 
              (max (max d1 d2) dc, l)
          | _ ->
              calc_depth_cmd cc k adjk l in

  let rec entl_iter entl l = match entl with
    | [] -> (0, l)
    | (_, (_, c, _, _, _, _)) :: entl ->
      let (d1, l) = calc_depth_cmd c 0 0 l in
      let (d2, l) = entl_iter entl l in
      (max d1 d2, l) 
  in

  entl_iter entl (List.map (fun x -> (x,0)) envl)


let rec upPure p k n = 
  let p = Pure.conj_one (E.eq (E.id (Id.level k)) E.one) p in
  if k >= n then p else upPure p (k + 1) n

(** Check whether an action decrements the heap paths *)
let checkdec spat pre post : bool = 

  let rec checkpost exp fld post = match post with
    | [] -> None
    | cs :: post ->
      begin match cs with
      | Csp_node (_, _, exp', fld', _) -> 
        if (equal_exp exp' exp) then
          begin
          (** get the pre field **)
          let f = Fld.diff fld fld' in
          if Fld.compare f Fld.emp == 0 then None
          else
            begin
            (** get the post field **)
            let f' = Fld.diff fld' fld in
            Some (f, f')
            end
          end
        else checkpost exp fld post
      | _ -> checkpost exp fld post
      end in
 
  let rec checkdiff pre post = match pre with
    | [] -> None
    | cs :: pre -> 
      begin match cs with 
      | Csp_node (_, _, exp, fld, _) -> 
        begin
        let f = checkpost exp fld post in
        if f == None then checkdiff pre post
        else Some (f, exp)
        end
      | _ -> checkdiff pre post 
      end in

  let rec contains e1 spat = match spat with
    | [] -> false
    | cs :: spat -> begin match cs with
      | Csp_node (_, _, exp, fld, _) -> begin
        if equal_exp exp e1 then true
        else contains e1 spat
        end
      | _ -> contains e1 spat
      end in

  let difffld = checkdiff pre post in match difffld with
    | None -> false
    | Some (Some (fld1, fld2), exp) -> begin 
      let (t1, e1) = Fld.fold (fun t e r -> (t, e)) fld1 (Misc.component_of_string "", E.zero) in
      if contains e1 spat then true 
      else false
      end
    | _ -> false


let check_dec_in_env (actl:(string * cprop) list) (envactl:(component * myaction) list) : bool = 
  let checkenv (actname,_) = 
    List.exists (fun (_,(s,pl,cr,cp,cq)) -> s = actname && checkdec cr cp cq) envactl in
  List.for_all checkenv actl

let mk_node id fld =
  Csp_node (tag_default, Misc.node_component, E.id id, fld, tag2_default)

(** Augment one action with the appropriate level_K and PathInc assertions *)
let augment_act (n:int) ((act: component * myaction), (k:int)) : 
   (component * myaction) = 
  let (rid, (actid, p, cr, cp, cq)) = act in
  let p = upPure p (k + 1) n in
  if checkdec cr cp cq then
    (rid, (actid, Pure.conj_one (E.eq (E.id Id.pathDec) E.one) p, 
                  mk_node Id.pathInc Fld.emp :: cr, 
                  cp, cq))
  else
    (rid, (actid, p, 
                  cr,
                  mk_node Id.pathInc Fld.emp :: cp, 
                  mk_node Id.pathInc (Fld.one Misc.list_data_tag E.one) :: cq)) 
 
let mk_new_cmd c = mk_cmd c Location.none  

let checker_code rgnl k =
  let tmp = Id.tempid () in
  let case1 = 
    mk_new_cmd (Cst_assume_exp (E.eq (E.id (Id.level k)) (E.num 1))) in
  let case2 = 
    mk_new_cmd (Cst_assume_exp (E.neq (E.id (Id.level k)) (E.num 1))) @
    mk_new_cmd (Cst_assert_exp (E.eq (E.id Id.pathDec) (E.num 1))) @
    mk_new_cmd (Cst_fldlookup (rgnl, tmp, E.id Id.pathInc, Misc.list_data_tag, Crmo_nonatomic)) @
    mk_new_cmd (Cst_assert_exp (E.eq (E.id tmp) E.zero)) in 
  mk_new_cmd (Cst_nondet (case1, case2))

let loop_header rgnl (k:int) : can_cmd =
  mk_new_cmd (Cst_kill (IdSet.add (Id.level k) ((*IdSet.add (Id.pathInc)*) (IdSet.singleton (Id.pathDec))))) @ 
  mk_new_cmd (Cst_fldassign (rgnl, [(E.id Id.pathInc, Misc.list_data_tag, E.zero)],ref [], Cwmo_nonatomic)) 

let assume_pd1 c =
  let assume = mk_cmd (Cst_assume_exp (E.eq (E.id Id.pathDec) (E.num 1))) Location.none in
  assume @ c

let rec int_fold f n v = 
  if n < 0 then v else int_fold f (n - 1) (f n v)

(** Instrument the code with the appropriate auxiliary variables and assertion checks. *)
let instrument_code allrgn (n : int) env (entl:(string * can_entailment) list) : (string * can_entailment) list =

  let rec can_cmd_iter cc k adjk = match cc with
    | [] -> []
    | c::cc ->
        match c.can_st_desc with
        | Cst_fldassign (rgnl, assnl, actlr, foo) ->
            let cc = can_cmd_iter cc k adjk in
            if check_dec_in_env !actlr env.g_guar.ge_actions then 
              c :: assume_pd1 cc 
            else 
              let assnl = (E.id Id.pathInc, Misc.list_data_tag, E.one) :: assnl in
              { c with can_st_desc = Cst_fldassign (rgnl, assnl, actlr, foo) } :: cc
        | Cst_loop (body, inv) ->
            let adjk' = adj_loop_depth body (k+1) (adjk+1) in
            let body = 
              loop_header allrgn (k+1) @
              can_cmd_iter body (k+1) adjk' @
              checker_code allrgn (k+1) in
            { c with can_st_desc = Cst_loop (body, inv) } :: can_cmd_iter cc k adjk
        | Cst_nondet (c1, c2) ->
            let c1 = can_cmd_iter c1 k (adj_loop_depth c1 k adjk) in
            let c2 = can_cmd_iter c2 k (adj_loop_depth c2 k adjk) in
            { c with can_st_desc = Cst_nondet (c1, c2) }  :: can_cmd_iter cc k adjk
        | Cst_goto (Cgo_continue n) -> 
            checker_code allrgn (k - n) @ 
            (c :: can_cmd_iter cc k adjk) 
        | _ ->
            c :: can_cmd_iter cc k adjk in

  let go_ent (fname, (cp1, c, c', cp2, lvs, lt)) =
    let c_new = can_cmd_iter c 0 0 in
    let lvs = IdSet.add Id.pathInc (IdSet.add Id.pathDec lvs) in
    let lvs = int_fold (fun k l -> IdSet.add (Id.level k) l) n lvs in
    mark_live_vars lvs c_new;
    (fname,(cp1, c_new, c', cp2, lvs, lt)) in

  List.map go_ent entl

(** print the actlr in Cst_fldassign **)
let print_actlr entl =
  let rec actl_iter rgnl actl = match actl with
    | [] -> ()
    | (actname,_)::actl ->
        pp "@.rgnl:";
        List.iter (fun r -> pp " %s" (string_of_component r)) rgnl;
        pp ", actname: %s@." actname;
        actl_iter rgnl actl in

  let rec can_cmd_iter cc = match cc with
    | [] -> ()
    | c::cc -> match c.can_st_desc with
        | Cst_fldassign(rgnl,_,actlr,_) ->
            actl_iter rgnl !actlr;
            can_cmd_iter cc
        | Cst_nondet(c1,c2) ->
            can_cmd_iter c1;
            can_cmd_iter c2;
            can_cmd_iter cc
        | Cst_loop(cmd,_) ->
            can_cmd_iter cmd;
            can_cmd_iter cc
        | _ ->
            can_cmd_iter cc in

  let rec entl_iter (entl : (string * can_entailment) list) = match entl with
    | [] -> ()
    | ent :: entl ->
        let (fname,ent) = ent in
        pp "@.Function %s:@." fname;
        let (_, c, _, _, _, _) = ent in
        can_cmd_iter c;
        entl_iter entl in

  entl_iter entl

(** print the ge_actions in g_guar **)
let pp_spatial f spat =
  pp_uform f (Pure.ptrue,spat)

let rec print_guar_env actl = match actl with
  | [] -> ()
  | act::actl ->
      let (c,myact) = act in
      let (s,p,s1,s2,s3) = myact in
      pp "@.resource %s,@. action name: %s,@. context pure: %a,@. context spat: %a,@. action pre: %a,@. action post: %a@."
          (string_of_component c)
          s
          Pure.pp p
          pp_spatial s1
          pp_spatial s2
          pp_spatial s3;
      print_guar_env actl

let check_lockfree 
    (env : global_env) 
    (ril : (component * Commands.res_init) list)
    (entl : (string * can_entailment) list) =

  pp "@.***** before augment:@.";
  print_guar_env env.g_guar.ge_actions;
  pp "@.*****@.";
  let (n, envl) = caldepth entl env.g_guar.ge_actions in
  env.g_guar.ge_actions <- List.map (augment_act n) envl;
  let entl = instrument_code (List.map fst ril) n env entl in

  begin match ril with 
  | [] -> ()
  | (r,_) :: _ -> 
     try 
       let cp = Hashtbl.find env.g_renv r in
       let cq = cprop_spred [mk_node Id.pathInc Fld.emp] in
       Hashtbl.replace env.g_renv r (cprop_star cq cp)
     with Not_found -> ()
  end;
 
  pp "@.***** after augment:@.";
  print_guar_env env.g_guar.ge_actions;
  pp "@.*****@.";

  pp_actions env.g_guar.ge_actions;

  actlr_clear entl;
  update_res_ht env.g_guar env.g_res_ht;
  
  infer_actions_once env [] entl

