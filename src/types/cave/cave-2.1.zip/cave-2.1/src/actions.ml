(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)
(** Rely-guarantee actions *)
open Misc
open Exp
open Assertions
open Commands
open Genarith

type myaction = string * Pure.t * can_spatial * can_spatial * can_spatial

type stab_env = {
    st_prover : prover ;
    st_abstraction : abstraction ;
    st_lin_hook : uform list -> uform list ;
    st_lin_exit : uform list -> unit (* raise exception to exit *) 
  }

type guar_env = {
    mutable ge_actions : (Misc.component * myaction) list ;
    mutable ge_changed : bool 
  }

let mk_guar_env () = { ge_actions = [] ; ge_changed = false }

(* -------------------------------------------------------------------------- *)
(** {2 Shorthands} *)
(* -------------------------------------------------------------------------- *)

let (@&) = Pure.conj_one

(* -------------------------------------------------------------------------- *)
(** {2 Arguments and statistics} *)
(* -------------------------------------------------------------------------- *)

(**
   If [verbose >= 2], print actions inferred.
   If [verbose >= 3], print #disjuncts in outer stabilization loop.
   If [verbose >= 4], print #disjuncts in inner stabilization loop. 
   If [verbose >= 5], print assertions in outer stabilization loop.
   If [verbose >= 6], print assertions in inner stabilization loop.
*)
let verbose = ref 1

let remember_result_hack = ref false

let lock_abstraction_heuristic = ref false

(** total number of iterations for all the calls to mk_stable_single *)
let stabilisation_iterations = ref 0

let args = 
  [("-vRG",  Arg.Set_int verbose, "<n> Display internal information (R/G)");
   ("-rr", Arg.Set remember_result_hack, " Abstract less so as to remember the result in actions");
   ]

(* -------------------------------------------------------------------------- *)
(** {2 Printing } *)
(* -------------------------------------------------------------------------- *)

let pp_internal_error () =
  pp "@.Internal error: please report.@."

let pp_action pl cr cp cq = match cp, cq with
  | [Csp_node(_,_,e,fld,_)], [Csp_node(_,_,e',fld',_)] when equal_exp e e' ->
       let (f1,fc,f2) = Fld.common fld fld' in
       pp "@[<v>  %a[%a ~> %a],%a@ | %a@]" 
	pp_exp e pp_fld f1 pp_fld f2 pp_fld fc
	pp_uform (pl, cr) 
  | _ ->   
       pp "@[<v>    %a@ ~> %a@ |  %a@]"
	 pp_uform (Pure.ptrue, cp)
	 pp_uform (Pure.ptrue, cq)
	 pp_uform (pl, cr)

let pp_actions actions =
  let n = ref 1 in
  List.iter 
    (fun (rid, (s,pl,cr,cp,cq)) ->
       pp "Action #%d %s: %s@.  " !n s (string_of_component rid);
       pp_action pl cr cp cq; pp "@."; n := !n + 1)
    actions


(* -------------------------------------------------------------------------- *)
(** {2 Global variables} *)
(* -------------------------------------------------------------------------- *)

let udom_false = udom_of_uform_list []

let normalize_uforms_aggr =
  List.reduce 
    (fun (p,sl) res -> 
       List.fold_append (fun p -> normalize_uform (p,sl))
         (Pure.normalize_aggr p) res)

let normalize_cforms_aggr =
  List.reduce 
    (fun ((p,sl),scpl) res -> 
       List.fold_append (fun p -> normalize_cform ((p,sl),scpl))
         (Pure.normalize_aggr p) res)

(** A bogus assertion, used when abstraction raises [Junk]. *)
let junk_node =
  cprop_spred
    [Csp_node(tag_default,component_of_string "Junk",E.id Id.junk,Fld.emp,tag2_default)]

(** [make_stable env cp rely] returns a [cp'] such that [cp |- cp'] and [stable_under cp rely] *)
let make_stable env cp actl = 
  let uform_list_to_cprop ufl = List.map (fun uf -> (uf,PNil)) ufl in

  (** Pseudo-fix-point calculation for stability under a single action *)
  let rec mk_stable_single act cou (udom, ufl_new) =
    if ufl_new = [] || cou >= 4 then udom else begin
      incr stabilisation_iterations;
      let _ =
	if !verbose >= 6 then 
	  pp "interf %s@ new: %a@." (act_name act) pp_cprop (uform_list_to_cprop ufl_new)
	else if !verbose >= 4 then
	  pp "interf %s@ new: %d@." (act_name act) (List.length ufl_new)
	else ()
      in
      (* 1. Calculate effect of a single interference step *)
      let ufl' =
        ufl_new
        |> uform_list_to_cprop
        |> interfere_once env.st_prover act
        |> List.map fst
        |> normalize_uforms_aggr
        |> env.st_lin_hook
      in
      (* 2. Join *)
      let res = env.st_abstraction.uform_join udom ufl' in
      (* Fail quickly on unpromising lin. points *)
      let () = env.st_lin_exit (snd res) in
      let _ =
	if !verbose >= 6 then 
	  pp "res: %a@." pp_cprop (uform_list_to_cprop (snd res))
      in
      (* 3. Repeat until fixed point *)
      mk_stable_single act (cou + 1) res
    end in
 
  (** Fix-point calculation for stability under a list of actions *)
  let rec mk_stable n (udom, ufl_new) =
    if ufl_new = [] then udom else begin
      let _ = 
	if !verbose >= 3 then begin
	  let ufl = uform_list_of_udom udom in
          pp "go2(%d,%d,%d)@." n (List.length ufl)(List.length ufl_new);
	  if !verbose >= 5 then
            pp "old: %a@ new: %a@." 
              pp_cprop (uform_list_to_cprop ufl)
              pp_cprop (uform_list_to_cprop ufl_new)
	end in
      (uform_list_of_udom udom, [])          (* TODO: Ugly -- breaks module abstraction!!! *)
      |> List.fold (fun act udom -> mk_stable_single act 0 (udom, ufl_new)) actl
                                             (* Stabilize each action separately *)
      |> uform_list_of_udom
      |> env.st_abstraction.uform_join udom  (* Join with existing domain *)
      |> mk_stable (n+1)                     (* Repeat until fixpoint *)
    end in

  (if !verbose >= 6 then pp "make_stable @ %a@." pp_cprop cp);
  try
    cp
    |> normalize_cforms_aggr
    |> aggr_kill_garbage_vars             (* Turn useless vars into existentials *)
    |> env.st_prover.nf_cprop []
    |> List.map fst
    |> normalize_uforms_aggr
    |> env.st_abstraction.uform_join udom_false (* Do an initial abstraction *)
    |> mk_stable 0                              (* Calculate fix-point *)
    |> uform_list_of_udom
    |> uform_list_to_cprop
  with Junk -> junk_node


(** Compute [eq] such that [ep |- eq] and [stable_under ep rely] *)
let stabilize env (rid,rely) ep =
  let get_shared rid (uf,scpl) = try
      ((uf, PList.remove_assq rid scpl), PList.assq rid scpl)
    with Not_found -> pp_internal_error (); assert false in
  let ep =
    let ep = remove_eform_duplicates ep in
    let ep = ext_transform (fun (uf,scpl) -> [(uf,PList.map_val normalize_cforms_aggr scpl)]) ep in (* VV_____________*)
    let cp = List.map cform_of_eform ep in
    map_eprop (existentials_rename_sub (prop_exfv cp IdSet.empty)) ep in
  let eq = (* post-condition outside block *)
    ext_transform (fun (cf : cform) ->
      let (cf_local,cp_shared) = get_shared rid cf in
      let (sub_unex,sub_toex) = existentials_rename_tonormal_sub (form_exfv cf_local IdSet.empty) in
      let cp = map_cform sub_unex cf_local in
      let cp_2 = map_cform sub_unex ((Pure.ptrue,snd(fst cf_local)),PNil) in
      let cp_shared = 
        try map_cprop sub_toex (env.st_prover.find_frame_cprop [] (cprop_star cp cp_shared) cp_2)
        with No_frame_found _ -> 
	  pp_internal_error ();
          pp "cp_shared: %a@." pp_cprop cp_shared;
	  pp "cf_local: %a@." pp_cform cf_local;
          assert false in
      let cp_shared = make_stable env cp_shared rely in
      cprop_cform (fst cf_local, PCons (rid, cp_shared, snd cf_local))) ep
  in
  (if !verbose >= 5 then
     pp "Stabilisation result:@ %a@." pp_eprop eq);
  eq


(* -------------------------------------------------------------------------- *)
(** {2 Action abstraction} *)
(* -------------------------------------------------------------------------- *)

let actabs_ids = idpool_new Id.gensym_str "!a"

let unify_spred inst sp1 sp2 = match sp1, sp2 with
 | Csp_node (_,s1,e1,cel1,_), Csp_node (_,s2,e2,cel2,_) ->
    if s1 <> s2 then None else
    let inst = Fld.subset cel1 cel2 @& E.eq e1 e2 @& inst in
    if Pure.is_false inst || Pure.has_unsat_eq inst then None else
    Some inst
 | Csp_listsegi (_,SINGLE (s1,fld1),e1,e2,e3,_,_,_), Csp_listsegi (_,SINGLE (s2,fld2),f1,f2,f3,_,_,_) ->
    if s1 <> s2 then None else
    let inst = Fld.subset fld1 fld2 @& E.eq e1 f1 @& E.eq e2 f2 @& E.eq e3 f3 @& inst in
    if Pure.is_false inst || Pure.has_unsat_eq inst then None else
    Some inst
  | _ -> None

let rec filter_emp_list inst acc sl = match sl with
  | [] ->
      if Pure.is_false inst || Pure.has_unsat_eq inst then None
      else Some (inst, acc)
  | Csp_listsegi (_,SINGLE _,e1,e2,e3,_,_,_) :: sl
    when equal_exp e1 e2 || equal_exp e3 E.empty_list ->
      let inst = E.eq e1 e2 @& E.eq e3 E.empty_list @& inst in
      filter_emp_list inst acc sl 
  | csp :: sl -> filter_emp_list inst (csp :: acc) sl

let unify_spatial inst sl1 sl2 =
  let rec do_insert y xl rev_prefix res = match xl with
    | [] ->     List.rev_append rev_prefix [y] :: res
    | x::xl' -> do_insert y xl' (x :: rev_prefix) (List.rev_append rev_prefix (y::xl) :: res) in
  let rec gen_cases xl = match xl with
    | [] -> [[]]
    | x::xl -> List.fold_left (fun res l -> do_insert x l [] res) [] (gen_cases xl) in
  let rec find_first f xl = match xl with
    | [] -> None
    | x::xl -> match f x with None -> find_first f xl | res -> res in
  let rec easy_unify inst sl1 sl2 = match sl1, sl2 with
    | [], [] -> Some inst
    | sp1::sl1, sp2::sl2 ->
	unify_spred inst sp1 sp2 >>= fun inst ->
	easy_unify inst sl1 sl2
    | _ -> None in
  find_first (easy_unify inst sl1) (gen_cases sl2)


(** [action_subaction act1 act2 = Some inst] iff [act1] is a subaction
    of [act2].
 *)
let action_subaction prover sub_back0
    (_name1,p1,sl_ctx1,sl_pre1,sl_post1) 
    (_name2,p2,sl_ctx2,sl_pre2,sl_post2) =
  (* 1. Fail quickly on unpromising cases *)
  if List.length sl_pre1 != List.length sl_pre2 then None
  else if List.length sl_post1 != List.length sl_post2 then None
  else
    let (sub, sub_back) = 
      idpool_combine2 actabs_ids
	(List.fold spred_exfv sl_ctx1
	   (List.fold spred_exfv sl_pre1
	      (List.fold spred_exfv sl_post1 
		 (Pure.exfv p1 IdSet.empty)))) in
    let p1 = Pure.map sub p1 in
    let sl_ctx1 = map_spat sub sl_ctx1 in
    let sl_pre1 = map_spat sub sl_pre1 in
    let sl_post1 = map_spat sub sl_post1 in
(*TODO!!!!!!!!!!!!!!*)
    unify_spatial Pure.ptrue sl_pre1 sl_pre2 >>= fun inst ->
    unify_spatial inst sl_post1 sl_post2 >>= fun inst ->

    let rec go n m xs = 
      if n > m || n < 0 then []
      else if n = m then [xs]
      else match xs with
	| [] -> assert false
	| x::xs ->
	    go n (m-1) xs
	    @ List.map (fun y->x::y) (go (n-1) (m-1) xs)
    in
    let rec find_first f xl = match xl with
      | [] -> None
      | x::xl -> match f x with None -> find_first f xl | res -> res in

    let sl_ctx2 = map_spat (Pure.to_sub inst) sl_ctx2 in
    filter_emp_list inst [] sl_ctx2 >>= fun (inst, sl_ctx2) -> 
    let x = find_first (unify_spatial inst sl_ctx2)
      (go (List.length sl_ctx2) (List.length sl_ctx1) sl_ctx1)
    in
    match x with
      | None ->
	  begin try
            let cp2 = normalize_cform ((Pure.conj inst p2, sl_ctx2),PList.nil) in
	    let res = prover.find_frame_cprop []
	      (cprop_uform (p1, sl_ctx1))
	      cp2 in
	    let res = List.map (fun ((p,_),_) -> ((p,[]),PNil)) res in
	    let res = map_cprop (sub_back >> sub_back0) res in
      (*let _ = pp "NONE %a@ |- %a@." pp_uform (p1, sl_ctx1) pp_cprop cp2 in*)
      (*let _ = pp "RES %a@." pp_cprop res in *)
	    Some res
	  with No_frame_found _ -> None 
	  end
      | Some inst -> 
	  begin try
            let cp2 = normalize_cform ((Pure.conj inst p2, spat_empty),PList.nil) in
      (*let _ = pp "SOME %a@ |- %a@." pp_uform (p1, sl_ctx1) pp_cprop cp2 in *)
	    let res = prover.find_frame_cprop []
	      (cprop_uform (p1, spat_empty))
	      cp2 in
	    let res = List.map (fun ((p,_),_) -> ((p,[]),PNil)) res in
	    let res = map_cprop (sub_back >> sub_back0) res in
      (*let _ = pp "RES %a@." pp_cprop res in *)
	    Some res
	  with No_frame_found _ -> None
	  end

let action_newname = 
  let n = ref 0 in
  fun () -> incr n; "inferred_" ^ string_of_int !n

(** Convert action to (pl,cr,cp,cq) format *)
let action_convert cp_ctx cp cq =
  List.fold (fun ((p_ctx, sl_ctx), _) -> 
  List.fold (fun ((p_pre, sl_pre), _) -> 
  List.fold (fun ((p_post, sl_post), _) -> 
    let pl = Pure.normalize_aggr (Pure.conj p_ctx (Pure.conj p_pre p_post)) in
    List.fold (fun p res -> (action_newname(),p,sl_ctx,sl_pre,sl_post)::res) pl
  ) cq) cp) cp_ctx []

(** Convert action into (cr,cp,cq) format *)
let action_deconvert (name,p,cr,cp,cq) =
(*  new_acts_one name p cr cp cq *)
  let cr = cprop_spred cr in
  let cp = cprop_uform (p,cp) in
  let cq = cprop_spred cq in
  new_acts name cr cp cq

(** Abstract action [(pl,cr,cp,cq)] *)
let action_abstract abstraction params sub_params (name,pl,cr,cp,cq) =
  (*pp "DDD0: %a@." pp_uform (pl, cr);*)
  let (pl,cr,cp,cq) =
    let sub = 
      if !remember_result_hack then
        mk_id_subst (fun x -> if x == Id.result then E.id Id.result else sub_params (E.id x)) 
      else sub_params in
    let sub = Pure.to_sub pl >> sub in
    (Pure.map sub_params (Pure.remove_eqs pl), 
     map_spat sub cr, map_spat sub cp, map_spat sub cq) in
  (*pp "DDD1: %a@." pp_uform (pl, cr);*) 
  let (pl,cr,cp,cq) = 
    let exfv = IdSet.inter (List.fold spred_exfv cr IdSet.empty) params in
    let exfv = List.fold spred_exfv cp (List.fold spred_exfv cq exfv) in
    let (sub_unex,sub_toex) = idpool_combine2 actabs_ids exfv in
    let (pl,cr) = match abstraction.uform_abs true [(Pure.map sub_unex pl, map_spat sub_unex cr)] with
      | [(pl,x)] -> (Pure.map sub_toex pl, map_spat sub_toex x)
      | ufl -> 
          pp_internal_error ();
          pp "+++ %a@." pp_uform (pl, cr);
          pp "=== %a@." pp_uform (Pure.map sub_unex pl, map_spat sub_unex cr);
          List.iter (pp "--- %a@." pp_uform) ufl;
          assert false in
    (*pp "DDD2: %a@." pp_uform (Pure.map sub_unex pl, map_spat sub_unex cr); *)
    let pl = List.fold 
      (fun x p -> match x with
	 | Csp_listsegi (tag,SINGLE _,e1,Enum 0,e3,e4,Cem_NE,_) ->
	     Pure.conj_one (E.neq E.zero e1) p
         | _ -> p) cr pl in
(*    let cr = *)
(*      if !remember_result_hack then cr (* Disable the filter *) *)
(*      else List.filter (function Csp_listsegi (_,SINGLE _,_,Enum 0,_,_,_,_) -> false | _ -> true) cr in *)
    let cr = List.map 
      (function
	 | Csp_listsegi (tag,SINGLE(snode,_),e1,e2,e3,e4,_,ds) ->
	     Csp_listsegi (tag,SINGLE(snode,Fld.emp),e1,e2,e3,e4,Cem_PE,Dset.emp)
	 | sp -> sp) cr in
    (pl,cr,cp,cq) in
  let (pl,cr,cp,cq) =
    if !remember_result_hack then
      let sub = mk_single_subst Id.result (sub_params (E.id Id.result)) in
      (Pure.map sub_params (Pure.remove_eqs pl), 
       map_spat sub cr, map_spat sub cp, map_spat sub cq)
    else (pl,cr,cp,cq) in
  let (fvp, fvq) = 
    (List.fold spred_fv cp IdSet.empty,
     List.fold spred_fv cq IdSet.empty) in
  (* Heuristic for locking and unlocking actions -- context is empty. *)
  let cr =
    if !lock_abstraction_heuristic 
       && IdSet.mem Id.tid fvp != IdSet.mem Id.tid fvq then
      spat_empty
    else cr 
  in
  (* Simplify @list predicates *)
  let (pl,cr,cp,cq) =
    let ff = (** Get all set expressions *)
      let exp_to_list e = match e with 
	| Efun(Sfn_list,el) -> el
	| e -> [e] in 
      let go_fld t e res = 
	if t == Misc.list_data_tag then exp_to_list e :: res 
	else res in
      let get_lval s res = match s with
	| Csp_node(_,_,_,fld,_) -> Fld.fold go_fld fld res
	| Csp_listsegi(_,SINGLE _,_,_,e,_,_,_) -> exp_to_list e :: res
	| _ -> res in
      List.fold get_lval in
    let ell = ff cr (ff cp (ff cq [])) in
    let sub = abstraction.list_abs ell in
    (Pure.map sub pl,map_spat sub cr, map_spat sub cp, map_spat sub cq)
  in
  (* pp "DDD3: %a@." pp_uform (pl, cr); *)
  (* Simplify @set predicates *)
  let (pl,cr,cp,cq) =
    let ff = (** Get all set expressions *)
      let exp_to_list e = match e with 
	| Efun(Sfn_set,el)  -> el
	| Efun(Sfn_list,el) -> List.map (E.fun1 Sfn_set_of_list) el
	| e -> [e] in 
      let go_fld t e res = 
	if t == Misc.list_data_tag then exp_to_list e :: res 
	else res in
      let get_lval s res = match s with
	| Csp_node(_,_,_,fld,_) -> Fld.fold go_fld fld res
	| Csp_listsegi(_,SINGLE _,_,_,e,_,_,_) -> exp_to_list e :: res
	| _ -> res in
      List.fold get_lval in
    let ell = (*ff cr*) (ff cp (ff cq [])) in
    let sub = abstraction.set_abs IdSet.empty ell in
    (Pure.map sub pl,map_spat sub cr, map_spat sub cp, map_spat sub cq)
  in
  let (fvp, fvq) = 
    (List.fold spred_fv cp IdSet.empty,
     List.fold spred_fv cq IdSet.empty) in
  let pl =
    let kills =
      IdSet.diff (Pure.exfv pl IdSet.empty)
	(spat_fold E.exfv cr (IdSet.union fvp fvq)) in
    let pl = Pure.kill_vars kills pl in
    (* TODO: Figure out better heuristic... *)
    let exfv2 = IdSet.filter Id.is_existential (IdSet.diff fvq fvp) in 
    let myf e = 
      let fv = E.exfv e IdSet.empty in
      IdSet.is_empty fv
      || (match e with Efun1 (Sfn_NOT, Eeq(Enum 0,_)) -> true | _ -> false)
      || ((match e with Efun2 (Sfn_list_lt,_,_) -> true | _ -> false) 
	  && IdSet.exists (function x -> IdSet.mem x exfv2) fv)
      || (match e with Efun1 (Sfn_NOT, Efun2 (Sfn_subset,_,_)) -> true | _ -> false) 
    in
    Pure.filter myf pl in
  (name,pl,cr,cp,cq)

(** Join action act to the action set recorded in [env]. *)
let action_join genv prover actlr sub_back rid act =
  let insert_act actlr (s,_,_,_,_) inst =
    let inst = 
      List.map (fun ((p,_),_) -> ((Pure.only_inst_eqs p,[]),PNil)) inst in
    let (l, cp) = 
      try
	let cp = List.assq s !actlr in
	let l = List.remove_assq s !actlr in
	(l, cp)
      with Not_found -> (!actlr, cprop_false) in
    actlr := (s, cprop_or inst cp) :: l in
  let myf (r,act') = 
    if r == rid then
      match action_subaction prover sub_back act act' with
	| None -> true
	| Some inst -> insert_act actlr act' inst; false
    else true
  in
  let myg (r,act') = r != rid || (action_subaction prover identity act' act == None) in
  match act with (_,_,_,[],[]) -> () (* Don't bother with emp ~> emp actions *) | _ -> 
  if List.for_all myf genv.ge_actions then begin
    let _ =
      if !verbose >= 2 then begin
	let (name,pl,cr,cp,cq) = act in
	pp "Added action: %s %s@." (string_of_component rid) name;
        pp_action pl cr cp cq; pp "@."
      end
    in
    insert_act actlr act cprop_empty;
    genv.ge_actions <- (rid,act) :: List.filter myg genv.ge_actions;
    genv.ge_changed <- true
  end

(* -------------------------------------------------------------------------- *)
(** {2 Entry points} *)
(* -------------------------------------------------------------------------- *)

(** Add action [cp_ctx | cp ~~> cq] to the guarantee. *)
let register_guarantee genv prover abstraction globs params actlr rid cp_ctx cp cq =
  if !verbose >= 6 then begin
    pp "register guarantee: %s@.@[<hv>%a@ |  %a @ ~> %a@]@."
      (string_of_component rid)
      pp_cprop cp_ctx
      pp_cprop cp
      pp_cprop cq
  end;
  (* 1. Forget local variables *)
  let (cp_ctx, cp, cq) =
    let cp_ctx = prop_kill_can_return cp_ctx in
    let cp = prop_kill_can_return cp in
    let cq = prop_kill_can_return cq in
    let fv = prop_fv cp_ctx (prop_fv cp (prop_fv cq IdSet.empty)) in
    let locals = IdSet.diff (IdSet.diff fv globs) params in
    let sub = mk_gensym_garb_subst_idset locals in
    (map_cprop sub cp_ctx, map_cprop sub cp, map_cprop sub cq) in
  (* Substitution for parameters *)
  let (sub, sub_back) = mk_gensym_garb_subst_idset2 params in
  (* 2. For each action... *)
  List.iter
     (action_abstract abstraction (map_idset sub params) sub
        >> action_join genv prover actlr sub_back rid)
     (action_convert cp_ctx cp cq)

(** Update the hashtable containing the actions *)
let update_res_ht genv ht = 
  genv.ge_changed <- false;
  List.iter (fun (rid,act) -> Hashtbl.replace ht rid (act,act))
    (Hashtbl.fold (fun k (v,_) r -> (k,v) :: r) ht []) ;
  List.iter 
    (fun (rid,act) ->
       let (o,n) = try Hashtbl.find ht rid with Not_found -> ([],[]) in
       let n = List.append (action_deconvert act) n in
       Hashtbl.replace ht rid (o,n))
    genv.ge_actions

