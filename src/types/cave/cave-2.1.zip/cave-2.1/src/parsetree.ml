(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)
open Misc

type p_type = string

type p_read_memory_order =
  | Prmo_nonatomic
  | Prmo_relaxed
  | Prmo_acquire
  | Prmo_seq_cst 

and p_write_memory_order =
  | Pwmo_nonatomic
  | Pwmo_relaxed of (string * string * a_expression list) option
  | Pwmo_release of (string * string * a_expression list) option
  | Pwmo_seq_cst of (string * string * a_expression list) option

and p_cas_memory_order =
  | Pcmo_seq_cst 
  | Pcmo_rel_acq
  | Pcmo_release
  | Pcmo_acquire
  | Pcmo_relaxed

and p_expression =
  { pexp_desc: p_expression_desc;
    pexp_loc: Location.t }

and p_expression_desc =
  | Pexp_ident of string
  | Pexp_num of int
  | Pexp_bool of bool
  | Pexp_prefix of string * p_expression
  | Pexp_infix of string * p_expression * p_expression
  | Pexp_cast of p_expression * p_type       (** impure *)
  | Pexp_fld of p_expression * component * p_read_memory_order (** impure *)
  | Pexp_cas of p_expression * component * p_expression * p_expression * p_cas_memory_order * p_read_memory_order (** impure *)
  | Pexp_new of p_type * p_expression        (** impure *)
  | Pexp_fun of string * p_expression list
  | Pexp_fcall of string * actual_params     (** impure *)

and actual_params = p_expression (*(string * Location.t)*) list * p_expression list 

and a_expression = p_expression
  (** without the impure cases *)

type dlink_kind = DL | XL

type a_proposition =
  | Aprop_exp of a_expression
  | Aprop_node of component * a_expression * (component * a_expression) list
  | Aprop_indpred of string * (string * Location.t) list * a_expression list
      * Location.t
  | Aprop_ifthenelse of a_expression * a_proposition * a_proposition
  | Aprop_star of a_proposition * a_proposition
  | Aprop_barbar of a_proposition * a_proposition
  | Aprop_box of component * a_proposition
  | Aprop_atomic_fld of a_expression * string * string * string * a_expression list
  | Aprop_escrow of string * a_expression list
  | Aprop_token of a_expression

type a_invariant = a_proposition option

type p_statement =
  { pstm_desc: p_statement_desc;
    pstm_loc: Location.t }

and p_statement_desc =
  | Pstm_exp of p_expression
  | Pstm_assign of string * p_expression option
  | Pstm_fldassign of (p_expression * component * p_expression) list * p_write_memory_order
  | Pstm_dispose of p_expression * p_expression
  | Pstm_block of p_statement list
  | Pstm_assume of p_expression
  | Pstm_if of p_expression option * p_statement * p_statement
  | Pstm_while of a_invariant * p_expression option * p_statement
  | Pstm_atomic of p_expression * p_statement
  | Pstm_withres of component * p_expression * p_statement * string
      * p_expression list
  | Pstm_action of p_statement * component * string * p_expression list
  | Pstm_parblock of (string option * string * actual_params) list
  | Pstm_interfere of component * string
  | Pstm_return of p_expression option
  | Pstm_break
  | Pstm_continue
  | Pstm_comment of string

type p_action = 
    string * (string * Location.t) list 
      * a_proposition * a_proposition * a_proposition
      * p_statement list * Location.t

type p_vars = (string * p_type * Location.t) list

type p_state_after = string * (string * Location.t) list * a_proposition * Location.t

type p_protocol_state = string * (string * Location.t) list * p_state_after list * string * a_proposition * Location.t

type p_item =
  | Pdec_options of (string * string * Location.t) list
  | Pdec_class of string * p_vars * Location.t
  | Pdec_var of string * p_type * bool * Location.t
  | Pdec_fun of string * p_type * (p_vars * p_vars)
      * (a_invariant * a_invariant) * (p_vars * p_statement list) * bool * Location.t
  | Pdec_resource of component * (string * Location.t) list * a_invariant
      * (p_vars * p_statement list) * p_statement list option * p_action list
      * Location.t
  | Pdec_indpred of string * (string * Location.t) list
      * a_proposition * Location.t
  | Pdec_comment of string
  | Pdec_protocol of string * p_protocol_state list * Location.t
  | Pdec_escrow of string * (string * Location.t) list * a_proposition * a_proposition * Location.t

type p_program = p_item list

let iter f =
  let rec loop = function
    | [] -> ()
    | {pstm_desc=stm; pstm_loc=loc} :: stms ->
	f loc stm;
	match stm with
	  | Pstm_block(stm_l) -> loop (stm_l @ stms)
	  | Pstm_if(_,s0,s1) -> loop (s0 :: s1 :: stms)
	  | Pstm_while(_,_,s) -> loop (s :: stms)
	  | Pstm_withres(_,_,s,_,_) -> loop (s :: stms)
	  | Pstm_action(s,_,_,_) -> loop (s :: stms)
	  | _ -> loop stms
  in loop

let a_prop_empty =
  Aprop_exp ({pexp_desc = Pexp_bool true; pexp_loc = Location.none})

let rec exp_is_pure e = match e.pexp_desc with
  | Pexp_prefix (_,e1) -> exp_is_pure e1
  | Pexp_infix (_,e1,e2) -> exp_is_pure e1 && exp_is_pure e2
  | Pexp_fun (_, el) -> List.for_all exp_is_pure el
  | Pexp_ident _ | Pexp_num _ | Pexp_bool _ -> true
  | Pexp_fld _ | Pexp_new _ | Pexp_fcall _ | Pexp_cast _ -> false
  | Pexp_cas _ -> false

