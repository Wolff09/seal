(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)

let print_stats = ref false


let verify (prg,parseok) =
  let comm = if Genarith.enabled () then "// " else "" in
  if parseok then begin
    let prover = Prover.default_prover in
    let abstraction = Abstraction.mk_abstraction Abstraction.default_options prover in
    Actions.stabilisation_iterations := 0;
    Abstraction.prover_calls := 0;
    match Tycheck.convert prg with
    | None ->
      Misc.pp "%sNOT Valid (typing error)@." comm; false
    | Some xs ->
      let init_time = Sys.time () in
      let valid = Linear.check_props prover abstraction xs in
      let final_time = Sys.time () in
      Misc.pp "%s%sValid@." comm (if valid then "" else "NOT ");
      Misc.pp "%sTime (RGSep%s): %.2fs@." comm
        (if !Linear.infer >= 2 then "+Linear" else "") (final_time -. init_time);
      if !print_stats then begin
        Misc.pp "@.=======================[ Stabilization statistics ]=========================";
        Misc.pp "@.Iterations:           %6d"   (!Actions.stabilisation_iterations);
        Misc.pp "@.Theorem prover calls: %6d@." (!Abstraction.prover_calls);
      end; valid
  end else begin
    Misc.pp "%sNOT Valid (syntax error)@." comm; false
  end

let parse_from_lex lex =
  try (Parser.program Lexer.token lex, true)
  with Location.Parse_error (s, loc) ->
    print_endline (Location.sprint loc ^ s); ([], false)

let verify_string s =
  let lex = Lexing.from_string s in
  verify (parse_from_lex lex)

let verify_stdin () =
  let lex = Lexing.from_channel stdin in
  Lexer.init lex "<stdin>";
  verify (parse_from_lex lex)
  
let verify_fnames fnames =
  verify 
    (List.fold_right
       (fun fname (r,b) ->
          let ic = open_in fname in
          let lex = Lexing.from_channel ic in
          Lexer.init lex fname;
          let (r',b') = parse_from_lex lex in 
          close_in ic;
          (List.append r r', b && b'))
       fnames ([],true))

