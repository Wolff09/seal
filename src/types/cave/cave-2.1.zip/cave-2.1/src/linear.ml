(******************************************************************************)
(*   __               ___     CAVE: Concurrent Algorithm VErifier             *)
(*  /     /\  \    / |        Copyright (c) Viktor Vafeiadis                  *)
(* |     /--\  \  /  |---                                                     *)
(*  \__ /    \  \/   |___     See LICENSE.txt for license.                    *)
(*                                                                            *)
(******************************************************************************)
(** Linearizability checking *)
open Misc
open Exp
open Assertions
open Commands
open Genarith
open Actions
open Symbsimp
open Lockfree

(* -------------------------------------------------------------------------- *)
(** {2 Shorthands} *)
(* -------------------------------------------------------------------------- *)

let (@%) ((pl,sl),scpl) pl' = ((Pure.conj pl' pl,sl),scpl)
let (@&) = Pure.conj_one
let (@@***) x y = eprop_star_assume x y
let (@@**) x y = eprop_star x y
let (@@&&) x y = cprop_pure x @@** y
let (@@&)  x y = Pure.one x @@&& y

let print loc = Location.print (!Misc.formatter) loc; pp 

let pp_generated_function fname n =
  if Genarith.enabled () then pp_function !Misc.formatter (fname,n)

let cform_to_sub ((p,_),_) = Pure.to_sub p

(* -------------------------------------------------------------------------- *)
(** {2 Arguments} *)
(* -------------------------------------------------------------------------- *)

(**
   If [verbose >= 1] 
   If [verbose >= 2], print loop invariants & actions inferred.
   If [verbose >= 3], print verification condition & action inference.
   If [verbose >= 4], print intermediate states.
   If [verbose >= 5], print stabilizations.
   If [verbose >= 6], print inferred frames.
*)
let verbose = ref 1

let left_mover_opt = ref false

let por_opt = ref false

let check_lf = ref false

(**
   If [infer >= 1], perform action inference.
   If [infer >= 2], perform linearization point inference. *)
let infer = ref 1

let args = 
  [("-v",            Arg.Set_int verbose, "<n> Display internal information");
   ("-lm",           Arg.Set left_mover_opt, " Enable left mover optimization");
   ("-lf",           Arg.Set check_lf, " Check lock-freedom");
   ("-por",          Arg.Set por_opt, " Enable POR optimization");
   ("-no_pure",      Arg.Set disable_pure_code_checking, " Disable finding linearization points in other threads");
   ("-no_infer_RG",  Arg.Unit (fun () -> infer := 0), " Do not infer rely/guarantee specifications");
   ("-infer_RG",     Arg.Unit (fun () -> infer := 1), " Infer rely/guarantee specifications");
   ("-ed",           Arg.Unit (fun () -> Actions.remember_result_hack := true; infer := 2), " Queue lintest");
   ("-linear_reuse", Arg.Unit (fun () -> infer := 3), " Infer linearization points");
   ("-linear",       Arg.Unit (fun () -> infer := 4), " Infer linearization points")]

let pp_line () =
  if !verbose >= 1 then
    pp "----------------------------------------------------------------------------@."

let pp_internal_error () =
  pp "@.Internal error: please report.@."

(* -------------------------------------------------------------------------- *)
(** {2 Global variables} *)
(* -------------------------------------------------------------------------- *)

let ident_ABS       = Id.create "ABS"
let ident_ABS_value = Id.create "ABS_value"

let linear_abs_pre = 
  (Pure.ptrue, [Csp_node(tag_default, node_component, E.id ident_ABS,
                        Fld.one Misc.list_data_tag (E.id ident_ABS_value),tag2_default)])

let str_is_fair x     = Str.string_match (Str.regexp_string "fair") x 0
let str_is_cutpoint x = (x = "cutpoint")

let cutpoint_counter  = ref 0

let next_cutpoint () =
  incr cutpoint_counter;
  "CUTPOINT_" ^ string_of_int (!cutpoint_counter)


let cprop_common_pure (cp : cprop) = 
  let rec do_common p cp = match cp with 
    | [] -> cprop_pure p
    | ((p',_),_)::cp -> do_common (Pure.common p p') cp in
  match cp with 
   | [] -> []
   | ((p,_),_)::cp -> do_common p cp
  

(* -------------------------------------------------------------------------- *)
(** {2 Linearizability checking} *)
(* -------------------------------------------------------------------------- *)

(** Inline abs.specs at linearization points. *)
let linear_merge env entl_specs (fname,ent) =
  try 
    let (_,spec,_,_,_,_) = List.assoc ("ABS_"^fname) entl_specs in
    let params = (Hashtbl.find env.g_fun_ht fname).fun_param in
    let params = List.fold IdSet.add (snd params) IdSet.empty in

    let symbexe p c =
      List.map fst p
      |> linear_symbexe env.g_prover c IdSet.empty 
      |> List.map (fun uf -> (uf,PNil))
    in

    let go abs_post p = 
      let sub = mk_gensym_garb_subst_idset (IdSet.diff (fv_norm_cprop p) params) in
      let p = map_cprop sub p in
      let pl = List.map (fun ((p,_),_) -> Pure.only_inst_eqs p) p in
      let p = match pl with 
        | [] -> Pure.ptrue
        | p::pl -> List.fold Pure.common pl p in
      and_cprop_pure abs_post p 
    in

    actlr_merge_linear symbexe go spec (fname,ent)
  with Not_found -> []

let linear_check_assignment old_guar env ril entl =
  if !verbose >= 1 then List.iter (fun (_, (_,c,_,_,_,_)) -> pp_linear_annot !Misc.formatter c) entl;
  if !verbose >= 1 then actlr_print entl;
  env.g_guar.ge_actions <- [];
  if !infer = 3 then begin
    actlr_iter 
      (fun (s,cp) ->
         if List.for_all (fun (_,(s',_,_,_,_)) -> s' != s) env.g_guar.ge_actions then begin
           let (rname, (actname, p, ctx, pre, post)) = 
             try List.find (fun (_,(s',_,_,_,_)) -> s' == s) old_guar
             with Not_found -> pp_internal_error (); assert false in
           let sub = mk_gensym_garb_subst_idset (IdSet.remove ident_ABS (fv_norm_cprop cp)) in
           let abs_pre = map_spat sub (snd linear_abs_pre) in
           match map_cprop sub cp with
             | [((p',abs_post),_)] -> 
               if List.exists (function Csp_node(_,_,e,_,_) -> e == E.id ident_ABS | _ -> false) abs_post
               then begin 
                 let abs_pre = map_spat (Pure.to_sub p') abs_pre in
                 let act = (rname, (actname, p (*Pure.conj p p'*), ctx, pre @ abs_pre, post @ abs_post)) in
                 env.g_guar.ge_actions <- act :: env.g_guar.ge_actions
               end
             | _ -> ()
         end 
      ) entl;
    List.iter
      (fun (rname, (actname, p, ctx, pre, post)) -> 
         if List.for_all (fun (_,(s',_,_,_,_)) -> s' != actname) env.g_guar.ge_actions then begin
           let ctx =
             if ctx == spat_empty && 
               (* Heuristic for locking and unlocking actions -- context is empty. *)
               let (fvp, fvq) = 
                 (List.fold spred_fv pre IdSet.empty,
                  List.fold spred_fv post IdSet.empty) in
               IdSet.mem Id.tid fvp != IdSet.mem Id.tid fvq then
               spat_empty 
             else
               Csp_node (tag_default, node_component, E.id ident_ABS, Fld.emp, tag2_default) :: ctx in
           let act = (rname, (actname, p, ctx, pre, post)) in
           env.g_guar.ge_actions <- act :: env.g_guar.ge_actions
         end 
      ) old_guar;
  end;
  actlr_clear entl;
  if !verbose >= 1 then pp_actions env.g_guar.ge_actions;
  infer_actions env ril entl

let is_act_used entl (_,((act,_,_,_,_) : myaction)) = 
  let rec go_act_used c = match c.can_st_desc with
    | Cst_fldassign (_,_,actlr,_) -> List.mem_assq act !actlr
    | Cst_nondet(c1,c2) ->  List.exists go_act_used c1 || List.exists go_act_used c2
    | Cst_loop (c1,_) -> List.exists go_act_used c1
    | Cst_assign _
    | Cst_cas _
    | Cst_fldlookup _
    | Cst_new _
    | Cst_dispose _
    | Cst_pfcall _
    | Cst_fcall2 _
    | Cst_assume _
    | Cst_interfere _
    | Cst_stabilize _
    | Cst_action_begin _
    | Cst_action_end _
    | Cst_goto _
    | Cst_kill _
    | Cst_assume_exp _
    | Cst_assert_exp _
    | Cst_comment _ -> false in
  List.exists (fun (_,(_,x,_,_,_,_)) -> List.exists go_act_used x) entl
 
let check_linearizable env ril entl entl_specs =
  if !verbose >= 1 then pp "@.====== [ Linearizability prover ] ==========================================@.";
  let old_acts = env.g_guar.ge_actions in
  let old_acts = List.filter (is_act_used entl) old_acts in
  actlr_upd cprop_common_pure entl;
  (* begin 
    if !verbose >= 1 then pp "@.====== [ Linearizability prover: sequential run ] ==========================@.";
    let res = infer_actions_once {env with g_no_interf_hack = true} ril entl in
    res
  end && *) begin 
    (* Guess lin.points for effectful methods *)
    let new_env = 
      { env with 
        g_abstraction = Abstraction.mk_abstraction Abstraction.sorting_options env.g_prover ;
        g_linear_pre = 
          Some (try (Hashtbl.find env.g_fun_ht "init_ABS").fun_post
      	  with Not_found -> cprop_empty) } in
    let entl0 = 
      List.fold_right 
        (fun h r -> List.concat (List.map (fun x -> List.map (fun y-> y::x) h) r))
        (List.filter (fun x->x<>[])
           (List.map (linear_merge new_env entl_specs) entl)) [[]]
    in
    let entl0 = (* deep copy needed :( *)
      List.map (List.map (fun (f,(p,c,q,r,s,l)) -> (f,(p,cmd_copy c,q,r,s,l)))) entl0 in
    if !verbose >= 1 then pp "@.LINEAR: We have %d case(s) to consider.@." (List.length entl0);
    let linear_iter = ref 0 in
    List.exists
      (fun entl_new ->
         incr linear_iter;
         if !verbose >= 1 then pp "@.====== [ Linearizability prover: iteration %2d ] ============================@."
           !linear_iter;
         linear_check_assignment old_acts new_env ril entl_new
      ) entl0
  end

(* -------------------------------------------------------------------------- *)
(** {2 Linearizability given an abstraction map} *)
(* -------------------------------------------------------------------------- *)


let check_linearizable_alt env ril entl entl_specs = false (* TODO *)


(* -------------------------------------------------------------------------- *)
(** {2 Queue linearizability via example testing } *)
(* -------------------------------------------------------------------------- *)

let find_function s entl = 
  try List.assoc s entl
  with Not_found -> 
    pp "ERROR: Could not find function %s.@." s;
    (cprop_empty, [], [], cprop_empty, IdSet.empty, Location.none)

let rec actlr_fold f c acc =
  let rec go c acc = match c.can_st_desc with
    | Cst_fldassign (_,_,r,_) -> List.fold f !r acc
    | Cst_nondet(c1,c2) -> List.fold go c1 (List.fold go c2 acc)
    | Cst_loop (c,_) -> List.fold go c acc
    | _ -> acc in
  List.fold go c acc

(** Returns all the actions in the guarantee of [code] *)
let gather_guar env code =
  let l = actlr_fold (fun (rid,cp) r -> 
      let cq = PList.findq r cprop_false rid in
      let r = PList.remove_assq rid r in
      PList.cons rid (cp @ cq) r) code PList.nil in
  env.g_guar.ge_actions
  |> List.filter (fun (rname,(actname,_,_,_,_)) -> PList.mem_assq actname l)
  |> List.map 
    (fun (rname, (actname, p, ctx, pre, post)) -> 
       match cprop_common_pure (PList.findq l cprop_empty actname) with
       | [((p', _),_)] -> 
	 let sub = Pure.to_sub p' in 
         (rname, (actname, Pure.map sub p, map_spat sub ctx, 
                  map_spat sub pre, map_spat sub post))
       | _ -> assert false)

let act_equal (_,(_,pl1,cr1,cp1,cq1)) (_, (_,pl2,cr2,cp2,cq2)) =
  Pure.compare pl1 pl2 = 0
  && compare_uform (Pure.ptrue, cr1) (Pure.ptrue, cr2) = 0
  && compare_uform (Pure.ptrue, cp1) (Pure.ptrue, cp2) = 0
  && compare_uform (Pure.ptrue, cq1) (Pure.ptrue, cq2) = 0

let rec union_acts l l' = match l' with
  | [] -> l 
  | x::l' when List.exists (act_equal x) l -> union_acts l l'
  | x::l' -> union_acts (x::l) l'

let act_sub_conj sub e (rid,(s,pl,cr,cp,cq)) =
  let pl' = Pure.map sub pl in
  let cr' = map_spat sub cr in
  let cp' = map_spat sub cp in
  let cq' = map_spat sub cq in
  if cr'==cr && cp'==cp && cq'==cq && Pure.compare pl pl' = 0 then
    (rid,(s,pl,cr,cp,cq))
  else (rid,(s,Pure.conj_one e pl',cr',cp',cq'))

let act_sub_star_ctx sub e sl act =
  let (rid,(s,pl,cr,cp,cq)) = act_sub_conj sub e act in
  (rid,(s,pl,sl@cr,cp,cq))

let act_sub_star_pq sub slp slq act =
  let (rid,(s,pl,cr,cp,cq)) = act_sub_conj sub E.one act in
  (rid,(s,pl,cr,slp@cp,slq@cq))

let update_ri what ids ss = match what with
  | Cri_inv (inv,loc) -> what
  | Cri_code (fv_post,c,loc) ->
      let c = List.map (fun x -> { can_st_desc = x;
                can_st_lv = IdSet.empty;
                can_st_loc = Location.none }) ss @ cmd_clear_copy c in
      let fvs = IdSet.union ids fv_post in
      mark_live_vars fvs c;
      Cri_code (fvs, c, loc)

let register_unit_function env s_new s_old =
  let info = Hashtbl.find env.g_fun_ht s_old in
  let info = { info with fun_param = ([], []) } in
  Hashtbl.add env.g_fun_ht s_new info

let pp_scpropList cpl =
  let n = ref 1 in
  List.iter
    (fun (loc,s,cp) ->
       pp "cpl loc , s , cp = (%s , %s , %a)@." loc s pp_cprop cp;
       n := !n + 1)
    cpl

let isequal_scprop (loc1,s1,cp1) (loc2,s2,cp2) =
 (s1 = s2) && (0 = compare_cprop cp1 cp2)

let compare_scprop (loc1,s1,cp1) (loc2,s2,cp2) =
   String.compare s1 s2

let compare_loc (loc1,s1,cp1) (loc2,s2,cp2) =
   String.compare loc1 loc2

let act_dup_nondup val_id entl fname =
  let rec go match_fname in_loop c (actl :  (string * string * cprop) list) = match c.can_st_desc with

    | Cst_fldassign (_,_,r,_) ->
        List.fold
          (fun (s,cp) actl -> 
             let loc = (Location.lineno_to_string c.can_st_loc) in
             pp "@[Line %s, action: %s@ [--- %a ---]@]@."
             loc s pp_cprop cp; 
             if in_loop || not (IdSet.mem val_id (prop_fv cp IdSet.empty)) then 
                (loc,s,cp) :: (loc,s,cp) :: actl 
             else begin
               if match_fname then (loc,s,cp) :: actl 
               else (loc,s,cp) :: (loc,s,cp) :: actl                   
             end
           )
          !r actl

    | Cst_nondet(c1,c2) -> 
       let lc1 = List.nth c1 ( (List.length c1) - 1 ) in
        let lc2 = List.nth c2 ( (List.length c2) - 1 ) in
        if (lc1.can_st_desc = Cst_goto Cgo_return) && (lc2.can_st_desc = Cst_goto Cgo_return) then 
          List.fold (go match_fname false) c2 (List.fold (go match_fname false) c1 actl)        
        else if (lc1.can_st_desc = Cst_goto Cgo_return) && (lc2.can_st_desc <> Cst_goto Cgo_return) then 
          List.fold (go match_fname in_loop) c2 (List.fold (go match_fname false) c1 actl)
        else if (lc1.can_st_desc <> Cst_goto Cgo_return) && (lc2.can_st_desc = Cst_goto Cgo_return) then 
          List.fold (go match_fname false) c2 (List.fold (go match_fname in_loop) c1 actl)
       else  
         List.fold (go match_fname in_loop) c2 (List.fold (go match_fname in_loop) c1 actl)

    | Cst_loop (c,_) -> List.fold (go match_fname true) c actl

    | _ -> actl in

  let actl =
    List.fold (fun (_fname,(_,c,_,_,_,_)) actl -> 
      if fname = _fname then 
       List.fold (go true false) c actl
      else begin
           List.fold (go false false) c actl 
           end) entl [] in
  let actl = List.sort compare_scprop actl in
  let rec dups l = match l with
    | [] -> []
    | [(loc,s,cp)] -> []
    | (loc1,s1,cp1) :: (loc2,s2,cp2) :: l -> if isequal_scprop (loc1,s1,cp1) (loc2,s2,cp2) then (loc1,s1,cp1) :: dups l else dups ((loc2,s2,cp2) :: l) in
  let d = dups actl in
  let nd = List.filter (fun x -> not (List.mem x d)) actl in
 (d, nd)

let act_dup_nondup1 val_id c =
  let rec go match_fname in_loop c (actl :  (string * string * cprop) list) = match c.can_st_desc with

    | Cst_fldassign (_,_,r,_) ->
        List.fold
          (fun (s,cp) actl ->
             let loc = (Location.lineno_to_string c.can_st_loc) in
             pp "@[Line %s, action: %s@ [--- %a ---]@]@."
             loc s pp_cprop cp;
             if not in_loop then (loc,s,cp) :: actl
             else actl
           )
          !r actl

    | Cst_nondet(c1,c2) ->
       let lc1 = List.nth c1 ( (List.length c1) - 1 ) in
        let lc2 = List.nth c2 ( (List.length c2) - 1 ) in
        if (lc1.can_st_desc = Cst_goto Cgo_return) && (lc2.can_st_desc = Cst_goto Cgo_return) then 
          List.fold (go match_fname false) c2 (List.fold (go match_fname false) c1 actl)
        else if (lc1.can_st_desc = Cst_goto Cgo_return) && (lc2.can_st_desc <> Cst_goto Cgo_return) then 
          List.fold (go match_fname in_loop) c2 (List.fold (go match_fname false) c1 actl)
        else if (lc1.can_st_desc <> Cst_goto Cgo_return) && (lc2.can_st_desc = Cst_goto Cgo_return) then 
          List.fold (go match_fname false) c2 (List.fold (go match_fname in_loop) c1 actl)
       else 
         List.fold (go match_fname in_loop) c2 (List.fold (go match_fname in_loop) c1 actl)

    | Cst_loop (c,_) -> List.fold (go match_fname true) c actl

    | _ -> actl in

 List.fold (go true false) c []
 
let rec print_locs uniquendlocs = match uniquendlocs with 
  [] -> ()
  | e::l -> pp "%a " pp_exp e; print_locs l

let append_actions d nd val_id (val2 : exp) n enq_actl deq_code deq_actl env =

  let do_subst actl (loc,s,ndcp) r =
    let (rid,(name,pl,cr,cp,cq)) = List.find (fun (_,(name,_,_,_,_))-> s = name) actl in
    let subl = List.map cform_to_sub ndcp in
    List.fold_cons (fun sub -> (rid,(name,pl,
                             map_spat sub cr,
                             map_spat sub cp,
                             map_spat sub cq))) subl r in
  let add_to_ctx sl (rid,(name,pl,cr,cp,cq)) = (rid,(name,pl,sl @ cr,cp,cq)) in

  let ndsubactl = List.reduce (do_subst enq_actl) nd in
  let dsubactl  = List.reduce (do_subst enq_actl) d in

  let actl = act_dup_nondup1 val_id deq_code in
  let deq_subst_actl = List.reduce (do_subst deq_actl) actl in

  let res_eq_val2 = act_sub_conj (mk_single_subst Id.result val2) E.one in
  let res_neq_val2 = act_sub_conj (mk_single_subst Id.result n)  (E.neq val2 n) in

  let deq_res_eq_val2_actl = List.map res_eq_val2 deq_subst_actl in
  let deq_res_neq_val2_actl = List.map res_neq_val2 deq_subst_actl in

  let val_eq_val2 = act_sub_conj (mk_single_subst val_id val2) E.one in
  let val_neq_val2 = act_sub_conj (mk_single_subst val_id n)  (E.neq val2 n) in
  let val_val2 = act_sub_conj (mk_single_subst val_id n) E.one in

  let (dsubactl, ndsubactl) = (List.map val_val2 dsubactl @ List.map val_neq_val2 ndsubactl,
                               List.map val_eq_val2 ndsubactl) in 

  let addu x l = if List.mem x l then l else x :: l in
  let uniquendlocs = List.fold (fun (loc,_,_) r -> addu loc r) nd [] in
 
  let rec create_cnodes fld uniquendlocs c1nodes =
     match uniquendlocs with
     | [] -> c1nodes
     | loc::l -> let c = Id.create ("!c"^loc) in
            env.g_globals <- IdSet.add c env.g_globals;
            let c1 = Csp_node (tag_default, Misc.node_component, E.id c, fld, tag2_default) in
            create_cnodes fld l (c1::c1nodes)
  in
  let cnodes = create_cnodes Fld.emp uniquendlocs [] in
  let c0nodes = create_cnodes (Fld.one Misc.list_data_tag E.zero) uniquendlocs [] in
  let c1nodes = create_cnodes (Fld.one Misc.list_data_tag E.one) uniquendlocs [] in

  let locnodes = 
    let idx = ref (-1) in
    List.map (fun loc -> 
               idx := !idx +1;
               (loc, List.nth cnodes !idx, List.nth c0nodes !idx, List.nth c1nodes !idx)
             ) uniquendlocs in 

  let locacts = List.map (fun act ->
      let (_,(name,_,_,_,_)) = act in
      let (loc,_,_) = List.find (fun (_,s,_) -> s = name) nd in
      (loc,act)) ndsubactl in

  let enq_c_taggedndsubactl = 
      List.concat(List.map(fun (loc,(rid,(name,pl,cr,cp,cq)))->
        List.map(fun (loc1,cnode,c0node,c1node) ->
         if loc1 = loc then (rid,(name,pl,cr,c0node::cp,c1node::cq))
         else (rid,(name,pl,cnode::cr,cp,cq))
       )locnodes 
  )locacts) in 

  let enq_c_taggeddsubactl = List.map (add_to_ctx cnodes) dsubactl in
  let deq_res_eq_val2_actl_tag_c = List.map (add_to_ctx cnodes) deq_res_eq_val2_actl in
  let deq_res_neq_val2_actl_tag_c = List.map (add_to_ctx cnodes) deq_res_neq_val2_actl in
  let enq_actl = (enq_c_taggedndsubactl @ enq_c_taggeddsubactl) in

(* now tag the deq actions *)

  let rec create_anodes fld actl anodes = match actl with
     | [] -> anodes
     | (loc,s,cp)::l -> let a = Id.create ("!a"^loc) in
            env.g_globals <- IdSet.add a env.g_globals;
            let a = Csp_node (tag_default, Misc.node_component, E.id a, fld, tag2_default) in
            create_anodes fld l (a::anodes)
  in
  let anodes = create_anodes Fld.emp actl [] in
  let a0nodes = create_anodes (Fld.one Misc.list_data_tag E.zero) actl [] in
  let a1nodes = create_anodes (Fld.one Misc.list_data_tag E.one) actl [] in

  let loc_anodes =
    let idx = ref (-1) in
    List.map (fun (loc,s,cp) ->
               idx := !idx +1;
               (loc, List.nth anodes !idx, List.nth a0nodes !idx, List.nth a1nodes !idx)
             ) actl in

  let locacts =
   List.map(fun (rid,(name,pl,cr,cp,cq)) ->
    let (loc,s,cp1) = List.find(fun (loc,s,cp1)-> s = name ) actl in
    (loc,(rid,(name,pl,cr,cp,cq)))
  )deq_res_eq_val2_actl_tag_c in
 
  let deq_res_eq_val2_actl_tag_c_a =
    List.concat(List.map(fun (loc,(rid,(name,pl,cr,cp,cq)))->
     List.map(fun (loc1,anode,a0node,a1node) ->
      if loc1 = loc then
        (rid,(name,pl,cr,a0node::cp,a1node::cq))
      else
        (rid,(name,pl,anode::cr,cp,cq))
   )loc_anodes
  )locacts) in
  
  let deq_res_neq_val2_actl_tag_c_a =  List.map (add_to_ctx anodes) deq_res_neq_val2_actl_tag_c in 
  let deq_ca_tagged_actl = deq_res_eq_val2_actl_tag_c_a @ deq_res_neq_val2_actl_tag_c_a in
  
  let enq_ca_tagged_actl = List.map(add_to_ctx anodes) enq_actl in
  env.g_guar.ge_actions <- (enq_ca_tagged_actl @ deq_ca_tagged_actl);
   
  (c0nodes,c1nodes,a0nodes,a1nodes) (* TODO *)


let rec update_stmt val2 c = match c.can_st_desc with
      | Cst_assign (x,e) when x = Id.result -> 
         mk_assume (E.eq e val2) c.can_st_loc
      | Cst_nondet(c1,c2) -> 
         mk_nondet (update_cmd val2 c1) (update_cmd val2 c2) c.can_st_loc
      | Cst_loop (c1,invo) ->
         mk_loop (update_cmd val2 c1) invo
           c.can_st_loc c.can_st_lv
      | _ -> [c] 

and update_cmd val2 (c : can_cmd) =
  List.concat (List.map (update_stmt val2) c)


(** Test VSf1 and VOrd properties *)
let check_qlin_test1 env ril pre val0 val1 val2 ids12 
      deq_code deq_guar deq_lvs enq_n_code enq_guar entl=
  pp_line ();
  pp "Test 1: VSf1 and Vord.@.@.";
  let enq12_string = "enqueue(!valA);enqueue(!valB)" in
  let deq2f_string = "dequeue(!valB)" in
  let ed3d2_guar = 
    let n = E.id (Id.gensym_garb val0) in
    union_acts
      (List.map (act_sub_conj (mk_single_subst Id.result n) (E.neq val1 n)) deq_guar)
      (List.map (act_sub_conj (mk_single_subst val0 n)      (E.neq val2 n)) enq_guar) in
  let enq12_ent =
    let code = cmd_fcall_concat (enq_n_code val1) (enq_n_code val2) in
    let lvs = IdSet.union ids12 deq_lvs in
    mark_live_vars lvs code;
    (enq12_string, (pre,code,[],cprop_empty,lvs,Location.none)) in
  let deq2f_ent =
    let code = cmd_clear_copy deq_code in
    let lvs = IdSet.add Id.result (IdSet.union ids12 deq_lvs) in
    let pre = cprop_pure (Pure.one (E.eq (E.id Id.result) val2)) in
    mark_live_vars lvs code;
    (deq2f_string, (pre,code,[],cprop_false,lvs,Location.none)) in
  register_unit_function env enq12_string "enqueue";
  register_unit_function env deq2f_string "dequeue";
  env.g_guar.ge_actions <- ed3d2_guar;
  if !verbose >= 1 then pp_actions env.g_guar.ge_actions;
  update_res_ht env.g_guar env.g_res_ht;
  if !verbose <= 2 then verbose := 2;

  let ril = List.map (fun (s,what) -> (s,update_ri what ids12 [Cst_assume pre])) ril in
  let new_env = { env with g_por_hack = true; 
                           g_abstraction = Abstraction.mk_abstraction Abstraction.valA_valB_options env.g_prover } in

  infer_actions_once new_env ril [enq12_ent] &&
  ( 
    let () =    
	pp_line ();
	pp_actions env.g_guar.ge_actions;
      in

    update_res_ht env.g_guar env.g_res_ht;
    infer_actions_once new_env ril [deq2f_ent] 
  )


(** Test VSf2 property *)
let check_qlin_test2 env ril pre val0 val2
    enq_code deq_code deq_guar deq_lvs enq_guar entl =
  pp_line ();
  pp "Test 2: VSf2.@.@.";

(*  let deq_code = cmd_clear_copy deq_code in 
  let deq2_ent =
    let code = deq_code in
    let lvs = IdSet.add Id.result (IdSet.union env.g_globals deq_lvs) in
    let post = cprop_empty in
    mark_live_vars lvs code;
    pp "deq(valB) code = @. %a @." pp_cmd code;
    ("dequeue(valB)", (pre,code,[],post,lvs,Location.none)) in

   register_unit_function env "dequeue(valB)" "dequeue";
   infer_actions_once env ril [deq2_ent] &&
   let () =    
	pp_line ();
	pp "@.Inferred %d actions:@." (List.length env.g_guar.ge_actions);
	pp_actions env.g_guar.ge_actions;
	actlr_upd cprop_common_pure [deq2_ent];
	actlr_print [deq2_ent];
	Hashtbl.iter
	  (fun r inv ->
	     pp "@.Invariant of resource %s:@.  %a@." (string_of_component r) pp_cprop inv)
	  env.g_renv
      in *)
   let enq_entl = List.filter(fun (_fname,(_,_,_,_,_,_))-> 
       _fname = "enqueue"     
   ) entl in 

   let enq_actl = enq_guar (*gather_guar env enq_code*) in
   let deq_actl = deq_guar(*gather_guar env deq_code*) in

   let (d,nd) = act_dup_nondup val0 enq_entl "enqueue" in
   let n = E.id (Id.gensym_garb val0) in
   let (c0nodes,c1nodes,a0nodes,a1nodes) = append_actions d nd val0 val2 n enq_actl deq_code deq_actl env in
   pp "@.finally test2 actions .... @.";
   pp_actions env.g_guar.ge_actions;
   pp_line();
	
  (*let deq11f_string = "dequeue(!valB);dequeue(!valB)" in *)
  let deq11f_string = "dequeue(!valB)" in
  let ed3d2_guar = 
     (List.map (act_sub_conj (mk_single_subst val0 n) (E.neq val2 n)) env.g_guar.ge_actions) in

  let deq11f_ent =
    let code = cmd_clear_copy deq_code in
    let lvs = IdSet.add Id.result (IdSet.union env.g_globals deq_lvs) in
    mark_live_vars lvs code;
    let int_post = cprop_uform (Pure.ptrue,a0nodes @ c1nodes) in
    let post = cprop_cform (uform_empty,List.fold (fun (s,what) r -> PCons(s,int_post,r)) ril PNil) in

    let pre = and_cprop_pure pre (Pure.one (E.eq (E.id Id.result) val2)) in
    pp "this post = %a @." pp_cprop post;

    mark_live_vars lvs code;
    pp "deq11f_ent code = @. %a @." pp_cmd code;
    (deq11f_string, (pre,code,[],post,lvs,Location.none)) in
	
  (* register_unit_function env enq1_string "enqueue"; *)
  register_unit_function env deq11f_string "dequeue";

  env.g_guar.ge_actions <- ed3d2_guar;
  pp "test2 env guarantee .... @.";
  if !verbose >= 1 then pp_actions env.g_guar.ge_actions;
  update_res_ht env.g_guar env.g_res_ht;
  if !verbose <= 2 then verbose := 2;

  let pre = cprop_star (cprop_uform (Pure.ptrue,a0nodes @ c0nodes)) pre in  
  pp "this pre = %a @." pp_cprop pre; 
  let ril = List.map (fun (s,what) -> (s,update_ri what env.g_globals [Cst_assume pre])) ril in
  let new_env = { env with g_abstraction = Abstraction.mk_abstraction Abstraction.valB_options env.g_prover } in
  infer_actions_once new_env ril [deq11f_ent]


let check_qlin env ril (entl : (string * can_entailment) list) =
  pp_line();
  pp "Aspect-oriented checking of queue linearizability...@.";
  pp_line();
  try
    let (enq_pre,enq_code,_,_,_,_) = find_function "enqueue" entl in
    let (deq_pre,deq_code,_,_,deq_lvs,_) = find_function "dequeue" entl in

    let deq_code = cmd_clear_copy (add_prophecy deq_code) in 
  
    let val_id = match (Hashtbl.find env.g_fun_ht "enqueue").fun_param with 
      | [], [id] -> id 
      | _ -> failwith "enqueue() must have exactly one argument@." in

    let enq_n_code n = 
      { can_st_desc = Cst_assign(val_id,n); 
        can_st_lv = IdSet.empty;
        can_st_loc = Location.none } :: cmd_clear_copy enq_code
    in

    let (val1, val2, ids12) = 
      let val1 = Id.create "!valA" in
      let val2 = Id.create "!valB" in
      (val1, E.id val2, IdSet.add val1 (IdSet.add val2 IdSet.empty)) in
    env.g_globals <- IdSet.union ids12 env.g_globals;

    let enq_guar = gather_guar env enq_code in
    let deq_guar = 
      let lvs = IdSet.add Id.result (IdSet.union env.g_globals deq_lvs) in
      mark_live_vars lvs deq_code;
      register_unit_function env "dequeue(Result)" "dequeue";
      let ent = ("dequeue(Result)", (deq_pre,deq_code,[],cprop_empty,lvs,Location.none)) in
      if not (infer_actions_once env ril [ent]) then 
        failwith "dequeue(Result) should succeed.";
      actlr_upd cprop_common_pure [ent];
      gather_guar env deq_code in


    (*let () =    
	pp_line ();
	pp "@.Dequeue actions %d: @." (List.length deq_guar);
	pp_actions deq_guar
      in *)
 
    let enq2_pre = map_cprop (mk_single_subst val_id val2) enq_pre in

    let pre1 =
      let enq1_pre = map_cprop (mk_single_subst val_id (E.id val1)) enq_pre in
      let d12_pre = Pure.one (E.neq (E.id val1) val2) in
      and_cprop_pure (cprop_star enq1_pre enq2_pre) d12_pre in
 
    check_qlin_test1 env ril pre1 val_id (E.id val1) val2 ids12 
      deq_code deq_guar deq_lvs enq_n_code enq_guar entl && 
    check_qlin_test2 env ril enq2_pre val_id val2 enq_code 
                    deq_code deq_guar deq_lvs enq_guar entl
  with Failure s ->
    pp "ERROR: %s@." s; false 


(* -------------------------------------------------------------------------- *)
(** {2 Entry point } *)
(* -------------------------------------------------------------------------- *)

let check_props prover abstraction (comments,fields,globals,pro_ht,esc_ht,fun_ht,res_ht,ril,entl) =
  let entl = if !left_mover_opt then left_mover_optimization entl else entl in
  all_fields := fields;
  if Genarith.enabled () then begin
    pp "#define assm(e) if (!(e)) {while(1){TerminationIgnore();}}@.@.";
    List.iter (pp "%s@.") comments;
  end;
  let (entl_specs,entl) = (* Ignore any functions starting with ABS_ *)
    let re = Str.regexp "ABS_" in
    List.partition (fun (s,_) -> Str.string_match re s 0) entl 
  in
  let env = 
    { g_prover = prover
    ; g_abstraction = abstraction
    ; g_globals = globals
    ; g_pro_ht = pro_ht
    ; g_esc_ht = esc_ht
    ; g_fun_ht = fun_ht
    ; g_res_ht = res_ht
    ; g_renv = Hashtbl.create 15
    ; g_guar = { ge_actions = [] ; ge_changed = false }
    ; g_actinf = true
    ; g_params = IdSet.empty
    ; g_no_interf_hack = false
    ; g_por_hack = !por_opt
    ; g_linear_pre = None
    ; g_linear_pure_code = []
    } in
  let res = if !infer >= 1 then begin
    infer_actions env ril entl
  end else 
    check_no_inference env ril entl in

  let res = res && (not !check_lf || check_lockfree env ril entl) in
  let res = res && (!infer <> 2 || check_qlin env ril entl) in
  let res = res && (!infer < 3 || check_linearizable env ril entl entl_specs) in
  if Genarith.enabled () then begin
    pp "int main() {@.";
    List.map fst entl
    |> List.filter (fun x -> not (str_is_cutpoint x) && not (str_is_fair x))
    |> List.iter (pp "  if (nondet()) %s(); else@.");
    pp "  {}@.}@.@.";
  end;
  res

