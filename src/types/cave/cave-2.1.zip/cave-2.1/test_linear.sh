#!/bin/bash
################################################################################
#    __               ___     CAVE: Concurrent Algorithm VErifier              #
#   /     /\  \    / |        Copyright (c) Viktor Vafeiadis                   #
#  |     /--\  \  /  |---                                                      #
#   \__ /    \  \/   |___     See LICENSE.txt for license.                     #
#                                                                              #
################################################################################
# Run the linearizability benchmarks

# Create a temporary file for holding the results 
TMPFILE=`mktemp -t cave.XXXXXXXXXX` || exit 1
echo "File" > $TMPFILE
echo "Result" >> $TMPFILE
echo "Time" >> $TMPFILE

# Stack benchmarks
for i in EXAMPLES/Treiber*.cav EXAMPLES/DCAS_stack*.cav ; do
	echo "File $i"
	echo "$i" >>$TMPFILE
	./cave -vSE 0 -v 0 -linear_reuse EXAMPLES/stack_spec.cav $i >>$TMPFILE
	tail -n 2 $TMPFILE
done 

# Queue benchmarks
for i in EXAMPLES/?*queue*.cav ; do
	echo "File $i"
	echo "$i" >>$TMPFILE
	./cave -vSE 0 -v 0 -linear_reuse EXAMPLES/queue_spec.cav $i >>$TMPFILE
	tail -n 2 $TMPFILE
done

# Set benchmarks
for i in EXAMPLES/CG_set*.cav EXAMPLES/LC_set*.cav EXAMPLES/*DCAS_set.cav ; do
	echo "File $i"
	echo "$i" >>$TMPFILE
	./cave -vSE 0 -v 0 -linear_reuse EXAMPLES/set_spec.cav $i >>$TMPFILE
	tail -n 2 $TMPFILE
done

# Display the results
paste - - - < $TMPFILE | sed 's/Time.*: //' | column -t -s $'\t'

# Delete the temporary file
rm -f $TMPFILE

