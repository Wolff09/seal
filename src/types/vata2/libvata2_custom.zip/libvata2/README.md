# libvata2
[![Travis Build Status](https://travis-ci.org/ondrik/libvata2.svg?branch=master)](https://travis-ci.org/ondrik/libvata2)
[![codecov](https://codecov.io/gh/ondrik/libvata2/branch/master/graph/badge.svg)](https://codecov.io/gh/ondrik/libvata2)
[![Coverity Scan Build Status](https://img.shields.io/coverity/scan/14973.svg)](https://scan.coverity.com/projects/ondrik-libvata2)

An attempt to revamp VATA

# Building

```
git clone https://github.com/ondrik/libvata2
cd libvata2
make release
```

# Documentation
see [this page](https://ondrik.github.io/libvata2/api)
