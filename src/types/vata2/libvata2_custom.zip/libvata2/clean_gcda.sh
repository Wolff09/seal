#/bin/sh
find . -name '*.gcda' -delete
