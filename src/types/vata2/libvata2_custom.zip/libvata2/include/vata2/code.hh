// TODO: add header

#ifndef _VATA2_CODE_HH_
#define _VATA2_CODE_HH_

namespace VATA2
{
namespace Code
{





// CLOSING NAMESPACES AND GUARDS
} /* Code */
} /* Vata2 */

#endif /* _VATA2_CODE_HH_ */
