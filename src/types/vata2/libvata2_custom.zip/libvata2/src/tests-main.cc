// TODO: some header

#define CATCH_CONFIG_MAIN
#include "../3rdparty/catch.hpp"
