// TODO: add header

#ifndef _VATA2_STR_HH_
#define _VATA2_STR_HH_

namespace Vata2
{
namespace Str
{

/// global constructor to be called at program startup (from vm-dispatch)
void init();

// CLOSING NAMESPACES AND GUARDS
} /* Str */
} /* Vata2 */

#endif /* _VATA2_STR_HH_ */
