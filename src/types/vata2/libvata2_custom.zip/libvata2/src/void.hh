// TODO: add header

#ifndef _VATA2_VOID_HH_
#define _VATA2_VOID_HH_

namespace Vata2
{
namespace Void
{

/// global constructor to be called at program startup (from vm-dispatch)
void init();

// CLOSING NAMESPACES AND GUARDS
} /* Void */
} /* Vata2 */

#endif /* _VATA2_VOID_HH_ */

