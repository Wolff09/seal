/* nfa-dispatch.cc --dispatcher for NFA-related functions
 *
 * Copyright (c) 2018 Ondrej Lengal <ondra.lengal@gmail.com>
 *
 * This file is a part of libvata2.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <tuple>

// VATA headers
#include <vata2/nfa.hh>
#include <vata2/vm-dispatch.hh>

// local headers
#include "dispatch-aux.hh"

using namespace Vata2::Nfa;
using namespace Vata2::VM;

using Vata2::Parser::ParsedSection;
using Vata2::dispatch::test_and_call;


namespace
{
	VMValue nfa_dispatch(
		const VMFuncName&  func_name,
		const VMFuncArgs&  func_args)
	{
		DEBUG_PRINT("calling function \"" + func_name + "\" for NFA");

		// we use throw to return result from test_and_call
		try {

			test_and_call("construct", func_name, {"Parsec"}, func_args, "NFA",
				*[](const ParsedSection& parsec) -> auto {
					return static_cast<VMPointer>(new Nfa(construct(parsec)));
				});

		}
		catch (VMValue res)
		{
			return res;
		}

		return VMValue("NaV", nullptr);
	}
}


void Vata2::Nfa::init()
{
	reg_dispatcher("NFA", nfa_dispatch);
}
